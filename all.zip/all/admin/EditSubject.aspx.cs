﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class back_end_Category : System.Web.UI.Page
{
    int id;
    public string ServerValue = String.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {


            if (Request.QueryString["Subject_ID"] != null)
            {

                DropDownList2.Items.Clear();
                DropDownList3.Items.Clear();
                string sem = "";
                string branch = "";
                string year = "";

                id = int.Parse(Request.QueryString["Subject_ID"].ToString());

                string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
                SqlConnection con = new SqlConnection(connectionString);

                con.Open();
                SqlDataAdapter da = new SqlDataAdapter("Select * from NMCE_Subject where Subject_ID='" + id + "'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    ServerValue = dt.Rows[0][1].ToString();
                    branch = dt.Rows[0][2].ToString();
                    year = dt.Rows[0][3].ToString();
                    sem = dt.Rows[0][4].ToString();
                }
                con.Close();

                DropDownList2.Items.Clear();
                DropDownList2.Items.Add(branch);
                con.Open();
                SqlCommand cmd = new SqlCommand("Select Distinct(Name) from tbl_adbranch", con);
                cmd.Connection = con;
                var obj = cmd.ExecuteReader();
                while (obj.Read())
                {
                    DropDownList2.Items.Add(obj.GetString(obj.GetOrdinal("Name")));
                }
                obj.Dispose();
                con.Close();

                DropDownList3.Items.Insert(0, new ListItem(year)); //updated code
                DropDownList3.Items.Add("First Year");
                DropDownList3.Items.Add("Second Year");
                DropDownList3.Items.Add("Third Year");

                DropDownList1.Items.Insert(0, new ListItem(sem));

            }
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        var name = this.Request.Form["cat"];
        string connectionString = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;

        SqlConnection con = new SqlConnection(connectionString);
        con.Open();

        id = int.Parse(Request.QueryString["Subject_ID"].ToString());

        string Query = "Update NMCE_Subject set Subject_Name = @Subject_Name,Branch = @branch,Year = @year, Semester = @sem where Subject_ID = @Subject_ID";
        SqlCommand cmd = new SqlCommand(Query, con);

        cmd.Parameters.Add(new SqlParameter("@Subject_ID", id));
        cmd.Parameters.Add(new SqlParameter("@Subject_Name", name));
        cmd.Parameters.Add(new SqlParameter("@year", DropDownList3.Text));
        cmd.Parameters.Add(new SqlParameter("@sem", DropDownList1.Text));
        cmd.Parameters.Add(new SqlParameter("@branch", DropDownList2.Text));

        cmd.ExecuteNonQuery();
        Response.Write("<script LANGUAGE='JavaScript' >alert('Update Successfully')</script>");
        Response.Redirect("SubjectMaster.aspx");
    }
}