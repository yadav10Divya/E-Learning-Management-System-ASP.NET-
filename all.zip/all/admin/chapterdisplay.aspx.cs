﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_chapterdisplay : System.Web.UI.Page
{
    public int Que_Id =0;
    int AutoIncrement()
    {
        int Cnt = 0;
        
        string ID = tb_Q_PID.Text;

        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand("Select Count(Exam_ID) from CET_QuestionPaperInfo1", con);
        Cnt = Convert.ToInt32(cmd.ExecuteScalar());
        if (Cnt > 0)
        {
            SqlCommand cmd1 = new SqlCommand("Select Max(Exam_ID) from CET_QuestionPaperInfo1", con);
            Cnt = Convert.ToInt32(cmd1.ExecuteScalar());
            Cnt += 1;
        }
        else
        {
            Cnt = 1;
        }

        return Cnt;
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Session.Abandon();
            Response.Redirect("../Default.aspx");
        }

        tb_Q_PID.Text = Convert.ToString(AutoIncrement());

        string connectionString1 = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        SqlConnection con1 = new SqlConnection(connectionString1);
        con1.Open();

        if (Que_Id==0)
        {
            Que_Id = 1;
            tb_Q_PID.Text = Convert.ToString(AutoIncrement());
        }

        else
        {
            Que_Id++;
            tb_Q_PID.Text = Convert.ToString(AutoIncrement());
        }


        if (!IsPostBack)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);

            con.Open();
            DataTable dt = new DataTable();

            tb_Standard.Text = Session["Std"].ToString();
            tb_T_Marks.Text = Session["TMarks"].ToString();
            tb_Time.Text = Session["Time"].ToString();

            if (Session["Phy"] != null)
            {
                lbl_Physics.Visible = true;
                tb_Physics.Visible = true;
                lbl_Physics.Text = Session["Phy"].ToString();
                tb_Physics.Text = Session["MPhy"].ToString();
                string Query1 = "Select ChapterName from CET_Chapter1 Where Standard = '" + tb_Standard.Text + "' And Subject ='" + lbl_Physics.Text + "'";
                SqlDataAdapter sda1 = new SqlDataAdapter(Query1, con);
                sda1.Fill(dt);
            }
            else
            {
                lbl_Physics.Visible = false;
                tb_Physics.Visible = false;
            }

            if (Session["chem"] != null)
            {
                lbl_Chemistry.Visible = true;
                tb_Chemistry.Visible = true;
                lbl_Chemistry.Text = Session["Chem"].ToString();
                tb_Chemistry.Text = Session["MChem"].ToString();
                //Filldgv("Select * from CET_tblSubject1");
                string Query2 = "Select ChapterName from CET_Chapter1 Where Standard = " + tb_Standard.Text + " And Subject ='" + lbl_Chemistry.Text + "'";
                SqlDataAdapter sda2 = new SqlDataAdapter(Query2, con);
                sda2.Fill(dt);
            }
            else
            {
                lbl_Chemistry.Visible = false;
                tb_Chemistry.Visible = false;
            }

            if (Session["Math"] != null)
            {
                lbl_Maths.Visible = true;
                tb_Maths.Visible = true;
                lbl_Maths.Text = Session["Math"].ToString();
                tb_Maths.Text = Session["MMaths"].ToString();
                string Query3 = "Select  ChapterName  from CET_Chapter1 Where Standard = " + tb_Standard.Text + " And Subject ='" + lbl_Maths.Text + "'";
                SqlDataAdapter sda3 = new SqlDataAdapter(Query3, con);
                sda3.Fill(dt);
            }
            else
            {
                lbl_Maths.Visible = false;
                tb_Maths.Visible = false;
            }

            if (Session["Bio"] != null)
            {
                lbl_Biology.Visible = true;
                tb_Biology.Visible = true;
                lbl_Biology.Text = Session["Bio"].ToString();
                tb_Biology.Text = Session["MBio"].ToString();
                string Query4 = "Select ChapterName from CET_Chapter1 Where Standard = " + tb_Standard.Text + " And Subject ='" + lbl_Biology.Text + "'";
                SqlDataAdapter sda4 = new SqlDataAdapter(Query4, con);
                sda4.Fill(dt);
            }
            else
            {
                lbl_Biology.Visible = false;
                tb_Biology.Visible = false;
            }
            GDV_Chapter_Show.DataSource = dt;
            GDV_Chapter_Show.DataBind();
            con.Close();
        }
    }

    protected void btn_View_Click(object sender, EventArgs e)
    {

        string ChapterNames = "";


        foreach (GridViewRow row in GDV_Chapter_Show.Rows)
        {
            if ((row.FindControl("CHKB_Select") as CheckBox).Checked)
            {
               
                string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                ChapterNames= ChapterNames+"$" + (row.Cells[1].FindControl("lbl_CName") as Label).Text;
                string CName = (row.Cells[1].FindControl("lbl_CName") as Label).Text;


                SqlCommand cmd = new SqlCommand("Select Distinct(reaction_name) From CETUpload_Reaction1 Where standard =" + tb_Standard.Text + " And chapter_name = '" + CName + "'", con);
                var Obj = cmd.ExecuteReader();

                cmd.Dispose();

                con.Close();
            }
        }

        Session["All_Chapters"] = ChapterNames;
        Session["Que_Id"] = Convert.ToString(AutoIncrement());
        Session["Time"] = tb_Time.Text;
        Response.Redirect("QDisplay.aspx?");

    }

    protected void tb_T_Ques_TextChanged(object sender, EventArgs e)
    {

    }
}