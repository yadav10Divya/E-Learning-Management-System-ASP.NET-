﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;

public partial class back_end_UpdateData1 : System.Web.UI.Page
{
    int id;
    public string UN;
    public string PS;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["id"] != null)
            {
                id=int.Parse(Request.QueryString["id"].ToString());
                string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
                SqlConnection con = new SqlConnection(connectionString);

                con.Open();

                SqlDataAdapter da = new SqlDataAdapter("Select * from CET_Department where id='" + id + "'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    UN = dt.Rows[0][2].ToString();
                    PS = dt.Rows[0][3].ToString();
                    DDL_Branch.Items.Add(dt.Rows[0][1].ToString());
                }
                SqlCommand cmd = new SqlCommand("Select Name from CET_branch1", con);
                cmd.Connection = con;
                var obj = cmd.ExecuteReader();
                while (obj.Read())
                {
                    DDL_Branch.Items.Add(obj["Name"].ToString());
                }
                obj.Dispose();
                con.Close();
            }

        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        con.Open();
        id = int.Parse(Request.QueryString["id"].ToString());
        UN = Request.Form["username"];
        PS = Request.Form["password"];

        var name = this.Request.Form["cat"];
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "Update CET_Department set Branch='" + DDL_Branch.Text + "',Username='" + UN + "',Password='" + PS + "' where id='" + id + "'";
        cmd.Connection = con;
    
        cmd.ExecuteNonQuery();
        Response.Write("<script LANGUAGE='JavaScript' >alert('Update Successfull')</script>");

        Response.Redirect("DepartmentMaster.aspx");
    }
}
