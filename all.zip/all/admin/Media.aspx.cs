﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_NoticeForStudent : System.Web.UI.Page
{
    int i;
    int j;
    int k;
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);

            con.Open();

            SqlCommand cmd = new SqlCommand("Select Name from CET_branch1", con);
            cmd.Connection = con;
            var obj = cmd.ExecuteReader();
            while (obj.Read())
            {
                DropDownList2.Items.Add(obj["Name"].ToString());
            }
            obj.Dispose();
            con.Close();
            DropDownList2.Items.Insert(0, new ListItem("All"));

            DropDownList2.Enabled = false;
            DropDownList3.Enabled = false;
            DropDownList4.Enabled = false;
        }

        try
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);


            con.Open();
            SqlCommand cmd1 = new SqlCommand("Select Max(id) from CET_Media ", con);
            cmd1.Connection = con;

            i = 0;
            i = Convert.ToInt32(cmd1.ExecuteScalar());
            i++;

        }
        catch (Exception ex)
        {
            i = 1;
        }


        try
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);


            con.Open();
            SqlCommand cmd1 = new SqlCommand("Select Max(id) from CET_MediaForStaff ", con);
            cmd1.Connection = con;

            j = 0;
            j = Convert.ToInt32(cmd1.ExecuteScalar());
            j++;

        }
        catch (Exception ex)
        {
            j = 1;
        }

        try
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);


            con.Open();
            SqlCommand cmd1 = new SqlCommand("Select Max(id) from CET_MediaForStud ", con);
            cmd1.Connection = con;

            k = 0;
            k = Convert.ToInt32(cmd1.ExecuteScalar());
            k++;

        }
        catch (Exception ex)
        {
            k = 1;
        }

    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        string Notice = Request.Form["notice"];
        string Category = DropDownList1.Text;
        string Branch = DropDownList2.Text;
        string Send = DropDownList3.Text;
        string Name = (DropDownList4.Text != "") ? DropDownList4.Text.Split(' ')[0] : DropDownList4.Text;

        if (FileUpload1.PostedFile.FileName != "" && Branch != "" && Name != "")
        {
            string instance = "";
            string token = "";

            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);

            con.Open();

            SqlCommand cmd2 = new SqlCommand("select * from CET_WhatsappAPI where id = 1", con);
            var obj1 = cmd2.ExecuteReader();
            while (obj1.Read())
            {
                instance = obj1["Instance"].ToString();
                token = obj1["Token"].ToString();
            }
            obj1.Dispose();

            if (Category == "All")
            {
                string filePath = FileUpload1.PostedFile.FileName;
                string filename = Path.GetFileName(filePath);
                string ext = Path.GetExtension(filename);
                string contenttype = String.Empty;
                string filePath1 = Server.MapPath("~/Uploads/") + Path.GetFileName(filePath);
                FileUpload1.SaveAs(filePath1);
                //Set the contenttype based on File Extension
                switch (ext)
                {
                    case ".doc":
                        contenttype = "application/vnd.ms-word";
                        break;
                    case ".docx":
                        contenttype = "application/vnd.ms-word";
                        break;
                    case ".xls":
                        contenttype = "application/vnd.ms-excel";
                        break;
                    case ".xlsx":
                        contenttype = "application/vnd.ms-excel";
                        break;
                    case ".jpg":
                        contenttype = "image/jpg";
                        break;
                    case ".png":
                        contenttype = "image/png";
                        break;
                    case ".gif":
                        contenttype = "image/gif";
                        break;
                    case ".pdf":
                        contenttype = "application/pdf";
                        break;
                    case ".txt":
                        contenttype = "application/txt";
                        break;
                }
                Stream fs = FileUpload1.PostedFile.InputStream;
                BinaryReader br = new BinaryReader(fs);
                Byte[] bytes = br.ReadBytes((Int32)fs.Length);


                string strQuery = "insert into CET_Media(id,Name,ContentType,Data,Branch,Media_From,Category) values (@id,@Name,@ContentType,@Data,@Branch,@From,@Category)";
                SqlCommand cmd = new SqlCommand(strQuery);
                cmd.Parameters.Add("@id", SqlDbType.VarChar).Value = i;
                cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = filename;
                cmd.Parameters.Add("@ContentType", SqlDbType.VarChar).Value = contenttype;
                cmd.Parameters.Add("@Data", SqlDbType.Binary).Value = bytes;
                cmd.Parameters.Add("@Branch ", SqlDbType.VarChar).Value = Branch;
                cmd.Parameters.Add("@From ", SqlDbType.VarChar).Value = "Admin";
                cmd.Parameters.Add("@Category ", SqlDbType.VarChar).Value = Category;


                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                SqlCommand cmd1 = new SqlCommand("select mobile from CET_tbl_Teacher_Register1 where branch = '" + Branch + "'", con);
                var obj = cmd1.ExecuteReader();

                while (obj.Read())
                {
                    string Number = obj["mobile"].ToString();

                   // string json1 = (new WebClient()).DownloadString("https://api.chat-api.com/instance" + instance + "/sendFile?token=" + token + "&phone=91'" + Number + "'&body=http://vita.ecssofttech.com/Uploads/" + filename + "&filename=" + filename.Split('.')[0] + "");

                }
                obj.Dispose();

                cmd1 = new SqlCommand("select Mobile_No from CET_tbl_Student_Register1 where Branch = '" + Branch + "'", con);
                obj = cmd1.ExecuteReader();

                while (obj.Read())
                {
                    string Number = obj["Mobile_No"].ToString();

                   // string json1 = (new WebClient()).DownloadString("https://api.chat-api.com/instance" + instance + "/sendFile?token=" + token + "&phone=91'" + Number + "'&body=http://vita.ecssofttech.com/Uploads/" + filename + "&filename=" + filename.Split('.')[0] + "");

                }

                con.Close();
            }
            else if (Category == "Staff")
            {
                if (Send == "All")
                {
                    string filePath = FileUpload1.PostedFile.FileName;
                    string filename = Path.GetFileName(filePath);
                    string ext = Path.GetExtension(filename);
                    string contenttype = String.Empty;
                    string filePath1 = Server.MapPath("~/Uploads/") + Path.GetFileName(filePath);
                    FileUpload1.SaveAs(filePath1);
                    //Set the contenttype based on File Extension
                    switch (ext)
                    {
                        case ".doc":
                            contenttype = "application/vnd.ms-word";
                            break;
                        case ".docx":
                            contenttype = "application/vnd.ms-word";
                            break;
                        case ".xls":
                            contenttype = "application/vnd.ms-excel";
                            break;
                        case ".xlsx":
                            contenttype = "application/vnd.ms-excel";
                            break;
                        case ".jpg":
                            contenttype = "image/jpg";
                            break;
                        case ".png":
                            contenttype = "image/png";
                            break;
                        case ".gif":
                            contenttype = "image/gif";
                            break;
                        case ".pdf":
                            contenttype = "application/pdf";
                            break;
                        case ".txt":
                            contenttype = "application/txt";
                            break;
                    }
                    Stream fs = FileUpload1.PostedFile.InputStream;
                    BinaryReader br = new BinaryReader(fs);
                    Byte[] bytes = br.ReadBytes((Int32)fs.Length);


                    string strQuery = "insert into CET_Media(id,Name,ContentType,Data,Branch,Media_From,Category) values (@id,@Name,@ContentType,@Data,@Branch,@From,@Category)";
                    SqlCommand cmd = new SqlCommand(strQuery);
                    cmd.Parameters.Add("@id", SqlDbType.VarChar).Value = i;
                    cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = filename;
                    cmd.Parameters.Add("@ContentType", SqlDbType.VarChar).Value = contenttype;
                    cmd.Parameters.Add("@Data", SqlDbType.Binary).Value = bytes;
                    cmd.Parameters.Add("@Branch ", SqlDbType.VarChar).Value = Branch;
                    cmd.Parameters.Add("@From ", SqlDbType.VarChar).Value = "Admin";
                    cmd.Parameters.Add("@Category ", SqlDbType.VarChar).Value = Category;


                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();

                    SqlCommand cmd1 = new SqlCommand("select Mobile_No from CET_tbl_Teacher_Register1 where branch = '" + Branch + "'", con);
                    var obj = cmd1.ExecuteReader();

                    while (obj.Read())
                    {
                        string Number = obj["mobile"].ToString();

                     //   string json1 = (new WebClient()).DownloadString("https://api.chat-api.com/instance" + instance + "/sendFile?token=" + token + "&phone=91'" + Number + "'&body=http://vita.ecssofttech.com/Uploads/" + filename + "&filename=" + filename.Split('.')[0] + "");

                    }
                    obj.Dispose();

                    con.Close();
                }
                else
                {
                    string filePath = FileUpload1.PostedFile.FileName;
                    string filename = Path.GetFileName(filePath);
                    string ext = Path.GetExtension(filename);
                    string contenttype = String.Empty;
                    string filePath1 = Server.MapPath("~/Uploads/") + Path.GetFileName(filePath);
                    FileUpload1.SaveAs(filePath1);
                    //Set the contenttype based on File Extension
                    switch (ext)
                    {
                        case ".doc":
                            contenttype = "application/vnd.ms-word";
                            break;
                        case ".docx":
                            contenttype = "application/vnd.ms-word";
                            break;
                        case ".xls":
                            contenttype = "application/vnd.ms-excel";
                            break;
                        case ".xlsx":
                            contenttype = "application/vnd.ms-excel";
                            break;
                        case ".jpg":
                            contenttype = "image/jpg";
                            break;
                        case ".png":
                            contenttype = "image/png";
                            break;
                        case ".gif":
                            contenttype = "image/gif";
                            break;
                        case ".pdf":
                            contenttype = "application/pdf";
                            break;
                        case ".txt":
                            contenttype = "application/txt";
                            break;
                    }
                    Stream fs = FileUpload1.PostedFile.InputStream;
                    BinaryReader br = new BinaryReader(fs);
                    Byte[] bytes = br.ReadBytes((Int32)fs.Length);


                    string strQuery = "insert into CET_MediaForStaff(id,Name,ContentType,Data,TeacherName,Branch,Media_From,Category) values (@id,@Name,@ContentType,@Data,@TName,@Branch,@From,@Category)";
                    SqlCommand cmd = new SqlCommand(strQuery);
                    cmd.Parameters.Add("@id", SqlDbType.VarChar).Value = j;
                    cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = filename;
                    cmd.Parameters.Add("@ContentType", SqlDbType.VarChar).Value = contenttype;
                    cmd.Parameters.Add("@Data", SqlDbType.Binary).Value = bytes;
                    cmd.Parameters.Add("@TName ", SqlDbType.VarChar).Value = Name;
                    cmd.Parameters.Add("@Branch ", SqlDbType.VarChar).Value = Branch;
                    cmd.Parameters.Add("@From ", SqlDbType.VarChar).Value = "Admin";
                    cmd.Parameters.Add("@Category ", SqlDbType.VarChar).Value = Category;


                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();

                    SqlCommand cmd1 = new SqlCommand("select mobile from CET_tbl_Teacher_Register1 where id = '" + Name + "'", con);
                    var obj = cmd1.ExecuteReader();

                    while (obj.Read())
                    {
                        string Number = obj["mobile"].ToString();

                       // string json1 = (new WebClient()).DownloadString("https://api.chat-api.com/instance" + instance + "/sendFile?token=" + token + "&phone=91'" + Number + "'&body=http://vita.ecssofttech.com/Uploads/" + filename + "&filename=" + filename.Split('.')[0] + "");

                    }
                }
            }
            else if (Category == "Student")
            {
                if (Send == "All")
                {
                    string filePath = FileUpload1.PostedFile.FileName;
                    string filename = Path.GetFileName(filePath);
                    string ext = Path.GetExtension(filename);
                    string contenttype = String.Empty;
                    string filePath1 = Server.MapPath("~/Uploads/") + Path.GetFileName(filePath);
                    FileUpload1.SaveAs(filePath1);
                    //Set the contenttype based on File Extension
                    switch (ext)
                    {
                        case ".doc":
                            contenttype = "application/vnd.ms-word";
                            break;
                        case ".docx":
                            contenttype = "application/vnd.ms-word";
                            break;
                        case ".xls":
                            contenttype = "application/vnd.ms-excel";
                            break;
                        case ".xlsx":
                            contenttype = "application/vnd.ms-excel";
                            break;
                        case ".jpg":
                            contenttype = "image/jpg";
                            break;
                        case ".png":
                            contenttype = "image/png";
                            break;
                        case ".gif":
                            contenttype = "image/gif";
                            break;
                        case ".pdf":
                            contenttype = "application/pdf";
                            break;
                        case ".txt":
                            contenttype = "application/txt";
                            break;
                    }
                    Stream fs = FileUpload1.PostedFile.InputStream;
                    BinaryReader br = new BinaryReader(fs);
                    Byte[] bytes = br.ReadBytes((Int32)fs.Length);

                    string strQuery = "insert into CET_Media(id,Name,ContentType,Data,Branch,Media_From,Category) values (@id,@Name,@ContentType,@Data,@Branch,@From,@Category)";
                    SqlCommand cmd = new SqlCommand(strQuery);
                    cmd.Parameters.Add("@id", SqlDbType.VarChar).Value = i;
                    cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = filename;
                    cmd.Parameters.Add("@ContentType", SqlDbType.VarChar).Value = contenttype;
                    cmd.Parameters.Add("@Data", SqlDbType.Binary).Value = bytes;
                    cmd.Parameters.Add("@Branch ", SqlDbType.VarChar).Value = Branch;
                    cmd.Parameters.Add("@From ", SqlDbType.VarChar).Value = "Admin";
                    cmd.Parameters.Add("@Category ", SqlDbType.VarChar).Value = Category;


                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();

                    SqlCommand cmd1 = new SqlCommand("select Mobile_No from CET_tbl_Student_Register1 where Branch = '" + Branch + "'", con);
                    var obj = cmd1.ExecuteReader();

                    while (obj.Read())
                    {
                        string Number = obj["Mobile_No"].ToString();

                      //  string json1 = (new WebClient()).DownloadString("https://api.chat-api.com/instance" + instance + "/sendFile?token=" + token + "&phone=91'" + Number + "'&body=http://vita.ecssofttech.com/Uploads/" + filename + "&filename=" + filename.Split('.')[0] + "");

                    }

                    con.Close();
                }
                else
                {
                    string filePath = FileUpload1.PostedFile.FileName;
                    string filename = Path.GetFileName(filePath);
                    string ext = Path.GetExtension(filename);
                    string contenttype = String.Empty;
                    string filePath1 = Server.MapPath("~/Uploads/") + Path.GetFileName(filePath);
                    FileUpload1.SaveAs(filePath1);
                    //Set the contenttype based on File Extension
                    switch (ext)
                    {
                        case ".doc":
                            contenttype = "application/vnd.ms-word";
                            break;
                        case ".docx":
                            contenttype = "application/vnd.ms-word";
                            break;
                        case ".xls":
                            contenttype = "application/vnd.ms-excel";
                            break;
                        case ".xlsx":
                            contenttype = "application/vnd.ms-excel";
                            break;
                        case ".jpg":
                            contenttype = "image/jpg";
                            break;
                        case ".png":
                            contenttype = "image/png";
                            break;
                        case ".gif":
                            contenttype = "image/gif";
                            break;
                        case ".pdf":
                            contenttype = "application/pdf";
                            break;
                        case ".txt":
                            contenttype = "application/txt";
                            break;
                    }
                    Stream fs = FileUpload1.PostedFile.InputStream;
                    BinaryReader br = new BinaryReader(fs);
                    Byte[] bytes = br.ReadBytes((Int32)fs.Length);

                    string strQuery = "insert into CET_MediaForStud(id,Name,ContentType,Data,StudentName,Branch,Media_From,Category) values (@id,@Name,@ContentType,@Data,@TName,@Branch,@From,@Category)";
                    SqlCommand cmd = new SqlCommand(strQuery);
                    cmd.Parameters.Add("@id", SqlDbType.VarChar).Value = k;
                    cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = filename;
                    cmd.Parameters.Add("@ContentType", SqlDbType.VarChar).Value = contenttype;
                    cmd.Parameters.Add("@Data", SqlDbType.Binary).Value = bytes;
                    cmd.Parameters.Add("@TName ", SqlDbType.VarChar).Value = Name;
                    cmd.Parameters.Add("@Branch ", SqlDbType.VarChar).Value = Branch;
                    cmd.Parameters.Add("@From ", SqlDbType.VarChar).Value = "Admin";
                    cmd.Parameters.Add("@Category ", SqlDbType.VarChar).Value = Category;


                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();

                    SqlCommand cmd1 = new SqlCommand("select Mobile_No from CET_tbl_Student_Register1 where Student_ID = '" + Name + "'", con);
                    var obj = cmd1.ExecuteReader();

                    while (obj.Read())
                    {
                        string Number = obj["Mobile_No"].ToString();
                        //https://api.chat-api.com/instance" + instance + "/sendFile?token=" + token + "&phone=91'" + Number + "'&body='" + filepath1 + "'&filename='" + filename + "'
                       // string json1 = (new WebClient()).DownloadString("https://api.chat-api.com/instance" + instance + "/sendFile?token=" + token + "&phone=91'" + Number + "'&body=http://vita.ecssofttech.com/Uploads/" + filename + "&filename=" + filename.Split('.')[0] + "");

                    }
                }
            }

            Response.Write("<script LANGUAGE= 'JavaScript' >alert ('Notice Send Successfully')</Script>");

        }
    }

    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList3.Text == "All")
        {
            DropDownList4.SelectedIndex = 0;
            DropDownList4.Enabled = false;
        }
        else
        {
            DropDownList4.Enabled = true;

            DropDownList4.Items.Clear();
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);

            con.Open();

            string TName = "";
            if (DropDownList1.Text == "Staff")
            {
                TName = "CET_tbl_Teacher_Register1";

                SqlCommand cmd = new SqlCommand("Select * from " + TName + " where branch = '" + DropDownList2.Text + "'", con);
                cmd.Connection = con;
                var obj = cmd.ExecuteReader();
                while (obj.Read())
                {
                    DropDownList4.Items.Add(obj["id"].ToString() + " " + obj["FirstName"].ToString() + " " + obj["MiddleName"].ToString() + " " + obj["LastName"].ToString());
                }

            }
            else
            {
                TName = "CET_tbl_Student_Register1";

                SqlCommand cmd = new SqlCommand("Select * from " + TName + " where branch = '" + DropDownList2.Text + "'", con);
                cmd.Connection = con;
                var obj = cmd.ExecuteReader();
                while (obj.Read())
                {
                    DropDownList4.Items.Add(obj["Student_ID"].ToString() + " " + obj["Stud_First_Name"].ToString() + " " + obj["Stud_Middle_Name"].ToString() + " " + obj["Stud_Last_Name"].ToString());
                }

            }
            con.Close();
        }
    }

    protected void DropDownList1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        if(DropDownList1.Text == "All")
        {
            DropDownList2.SelectedIndex = 0;
            DropDownList2.Enabled = false;

            DropDownList3.SelectedIndex = 0;
            DropDownList3.Enabled = false;

            DropDownList4.Items.Insert(0, new ListItem("All", "-1"));
            DropDownList4.SelectedIndex = 0;
            DropDownList4.Enabled = false;
        }
        else
        {
            DropDownList2.Enabled = true;

            DropDownList3.SelectedIndex = 0;
            DropDownList3.Enabled = false;

            DropDownList4.Items.Insert(0, new ListItem("All", "-1"));
            DropDownList4.SelectedIndex = 0;
            DropDownList4.Enabled = false;
        }
    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList2.Text == "All")
        {
            DropDownList3.SelectedIndex = 0;
            DropDownList3.Enabled = false;

            DropDownList4.Items.Insert(0, new ListItem("All", "-1"));
            DropDownList4.SelectedIndex = 0;
            DropDownList4.Enabled = false;
        }
        else
        {
            DropDownList3.SelectedIndex = 0;
            DropDownList3.Enabled = true;

            DropDownList4.Items.Insert(0, new ListItem("All", "-1"));
            DropDownList4.SelectedIndex = 0;
            DropDownList4.Enabled = false;
        }
    }
}