﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class back_end_Category : System.Web.UI.Page
{
    int i;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Session.Abandon();
            Response.Redirect("../Default.aspx");
        }
        if (!IsPostBack)
        {
           getData();
        }
        try
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);

            con.Open();
            SqlCommand cmd1 = new SqlCommand("Select Max(Subject_ID) from CET_tblSubject1 ", con);
            cmd1.Connection = con;

            i = 0;
            i = Convert.ToInt32(cmd1.ExecuteScalar());
            i++;

        }
        catch (Exception ex)
        {
            i = 1;
        }


    }
    public void getData()
    {
        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        try
        {
            
            con.Open();
            SqlCommand cmd = new SqlCommand("Select Distinct(Name) from CET_branch1", con);
            cmd.Connection = con;
            var obj = cmd.ExecuteReader();
            while (obj.Read())
            {
                DropDownList2.Items.Add(obj.GetString(obj.GetOrdinal("Name")));
            }
            obj.Dispose();
            con.Close();
        }
        catch (Exception ex)
        {

        }


        con.Open();
        
        //SqlDataAdapter da = new SqlDataAdapter("select id,Cat_Name,Data from tblFiles1", con);
        SqlDataAdapter da = new SqlDataAdapter("select * from CET_tblSubject1", con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        grdView.DataSource = dt;
        grdView.DataBind();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        
       
        var sem = DropDownList1.Text;
        var branch = DropDownList2.Text;
        var year = DropDownList3.Text;
        System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings["ConString"].ConnectionString);

        con.Open();
        string strQuery = "insert into CET_tblSubject1(Subject_ID,Subject_Name,Semester,Branch,Year) values(@id,@Subject_Name,@Sem,@branch,@year)";
        SqlCommand cmd = new SqlCommand(strQuery);
        cmd.Parameters.Add("@id", SqlDbType.VarChar).Value = i;
        cmd.Parameters.Add("@Subject_Name", SqlDbType.VarChar).Value = cat.Text;
        cmd.Parameters.Add("@Sem", SqlDbType.VarChar).Value = sem;
        cmd.Parameters.Add("@branch", SqlDbType.VarChar).Value = branch;
        cmd.Parameters.Add("@year", SqlDbType.VarChar).Value = year;

        cmd.Connection = con;
        cmd.ExecuteNonQuery();
        Response.Write("<script LANGUAGE='JavaScript' >alert('Added Successfull')</script>");
        getData();

    }


    protected void grdView_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /* This condition work when click on edit button */
        if (e.CommandName == "lnkbtnEdit")
        {
            int id = int.Parse(e.CommandArgument.ToString());
           
            Response.Redirect("UpdateData.aspx?Subject_ID=" + id); /* Pass id in querystring for updating record */
            //Response.Redirect("UpdateData.aspx?Subject_Name = name ");
            getData();
        }

        /* This condition work when click on delete button */
        if (e.CommandName == "lnkbtnDelete")
        {
            int id = int.Parse(e.CommandArgument.ToString());
            System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings["ConString"].ConnectionString);
            var name = this.Request.Form["cat"];





            //SqlCommand cmd = new SqlCommand("delete from tblFiles1 where ID='" + id + "'", con);
            SqlCommand cmd = new SqlCommand("delete from CET_tblSubject1 where Subject_ID='" + id + "'", con);
            con.Open();
           cmd.ExecuteNonQuery();
           con.Close();
           getData(); /* Reload gridview */
        }
    }

    
}