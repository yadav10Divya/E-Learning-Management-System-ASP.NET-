﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_DeleteExam : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Session.Abandon();
            Response.Redirect("../Default.aspx");
        }
        if (!IsPostBack)
        {
            getData();
        }
    }
    public void getData()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConString"].ConnectionString);



        con.Open();

        //SqlDataAdapter da = new SqlDataAdapter("select id,Cat_Name,Data from tblFiles1", con);
        SqlDataAdapter da = new SqlDataAdapter("select Exam_ID,Exam_Name from CET_QuestionPaperInfo1", con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        grdView.DataSource = dt;
        grdView.DataBind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }

    protected void grdView_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /* This condition work when click on delete button */
        if (e.CommandName == "lnkbtnDelete")
        {
            int id = int.Parse(e.CommandArgument.ToString());
            System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings["ConString"].ConnectionString);
            var name = this.Request.Form["cat"];

            //SqlCommand cmd = new SqlCommand("delete from tblFiles1 where ID='" + id + "'", con);
            SqlCommand cmd = new SqlCommand("delete from CET_QuestionPaperInfo1 where Exam_ID='" + id + "'", con);
            con.Open();
            cmd.ExecuteNonQuery();

            cmd = new SqlCommand("delete from CET_Select_Exam_Question1 where Que_Paper_id='" + id + "'", con);
            cmd.ExecuteNonQuery();

            con.Close();
            getData(); /* Reload gridview */
        }
    }
}