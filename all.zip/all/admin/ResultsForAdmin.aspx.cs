﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_ResultsForAdmin : System.Web.UI.Page
{
    public string ExamID;

    public int id;

    public int Count;

    public int NoCount;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Session.Abandon();
            Response.Redirect("../Default.aspx");
        }

        id = int.Parse(Request.QueryString["id"]);

        string connectionString = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        con.Open();
        DataTable dt1 = new DataTable();

        string Query1 = "select a.id,a.ExamID,a.PRN,a.Seat_No,a.Name,a.TotalQuestions,a.SolvedQuestions,a.TotalMarks,a.ObtainedMarks from CET_StudentResult1 a INNER JOIN (SELECT DISTINCT PRN, MAX(SolvedQuestions) SolvedQuestions, MAX(id) id FROM CET_StudentResult1 b where ExamID = " + id + " GROUP BY PRN) b on a.id = b.id";

        SqlDataAdapter sda1 = new SqlDataAdapter(Query1, con);
        sda1.Fill(dt1);
        ExamID = id.ToString();
        abc.DataSource = dt1;
        abc.DataBind();

        Count = dt1.Rows.Count;

        SqlCommand cmd = new SqlCommand("select Exam_Name,Branch,Year,Semester from CET_QuestionPaperInfo1 where Exam_ID = '" + ExamID + "'", con);

        var obj = cmd.ExecuteReader();
        string branch = "", year = "", sem = "";
        while(obj.Read())
        {
            ExamID = obj[0].ToString();
            branch = obj[1].ToString();
            year = obj[2].ToString();
            sem = obj[3].ToString();
        }
        obj.Dispose();

        Query1 = "Select * from CET_tbl_Student_Register1 QP where QP.Branch = '" + branch + "' and QP.Year = '" + year + "' and QP.Semester = '" + sem + "' and QP.PRN Not in (select PRN from CET_StudentResult1 where ExamID = " + id + ") order by PRN";

        DataTable dt = new DataTable();
        SqlDataAdapter sda2 = new SqlDataAdapter(Query1, con);
        sda2.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();

        NoCount = dt.Rows.Count;


    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        //Allows for printing
    }
    protected void abc_SelectedIndexChanged(object sender, EventArgs e)
    {
        //int index = abc.SelectedRow.RowIndex;
        // int ID = Convert.ToInt32(abc.SelectedRow.Cells[0].Text);
        // string message = "Row Index: " + index + "\\ContactID: ";
        //  Response.Write("<script language='javascript'>window.alert('Record Updated Successfully ');</script>");
        foreach (GridViewRow row in abc.Rows)
        {
            if (row.RowIndex == abc.SelectedIndex)
            {
                row.BackColor = ColorTranslator.FromHtml("#A1DCF2");
                row.ToolTip = string.Empty;
            }
            else
            {
                row.BackColor = ColorTranslator.FromHtml("#FFFFFF");
                row.ToolTip = "Click to select this row.";
            }
        }
    }

    protected void abc_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(abc, "Select$" + e.Row.RowIndex);
            e.Row.ToolTip = "Click to select this row.";
        }
    }

    protected void abc_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "lnkbtnEdit")
        {
            int id1 = int.Parse(e.CommandArgument.ToString());

            string connectionString = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlDataAdapter sa = new SqlDataAdapter("select * from CET_tbl_Student_Register1 where PRN='" + id1 + "'", con);
            DataTable dt = new DataTable();
            sa.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Session["RollNo"] = Convert.ToInt32(dt.Rows[0][0]);
                Session["Name"] = dt.Rows[0][1].ToString() + " " + dt.Rows[0][2].ToString() + " " + dt.Rows[0][3].ToString();
                Session["Branch"] = dt.Rows[0][4].ToString();
                Session["prn"] = dt.Rows[0][9].ToString();
                Session["ExamID"] = id;
            }

            Response.Redirect("ResultAnalysis.aspx");
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        ExportGridToExcel(abc,"_Exam_Result.xls");
    }
    private void ExportGridToExcel(GridView grd,string name)
    {
        abc.Columns[0].Visible = false;
        Response.Clear();
        Response.Buffer = true;
        Response.ClearContent();
        Response.ClearHeaders();
        Response.Charset = "";
        string FileName = ExamID + name;
        StringWriter strwritter = new StringWriter();
        HtmlTextWriter htmltextwrtter = new HtmlTextWriter(strwritter);
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.ContentType = "application/vnd.ms-excel";
        Response.AddHeader("Content-Disposition", "attachment;filename=" + FileName);
        grd.GridLines = GridLines.Both;
        grd.HeaderStyle.Font.Bold = true;
        grd.RenderControl(htmltextwrtter);
        Response.Write(strwritter.ToString());
        Response.End();

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        ExportGridToExcel(GridView1,"_Absent_Students.xls");
    }
}