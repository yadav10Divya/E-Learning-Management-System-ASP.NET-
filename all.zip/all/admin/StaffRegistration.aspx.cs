﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_StaffRegistration : System.Web.UI.Page
{
    int i;
    public string firstname;
    public string middlename;
    public string lastname;

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {

            if (!Page.IsPostBack)
            {
                Button1.CausesValidation = false;

                string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
                SqlConnection con = new SqlConnection(connectionString);

                con.Open();

                string com = "Select * from CET_branch1";
                SqlDataAdapter adpt = new SqlDataAdapter(com, con);
                DataTable dt = new DataTable();
                adpt.Fill(dt);
                DropDownList1.DataSource = dt;
                DropDownList1.DataBind();
                DropDownList1.DataTextField = "Name";
                DropDownList1.DataValueField = "Name";
                DropDownList1.DataBind();
            }
        }

        try
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);

            con.Open();
            SqlCommand cmd1 = new SqlCommand("Select Max(id) from CET_tbl_Teacher_Register1 ", con);
            cmd1.Connection = con;

            i = 0;
            i = Convert.ToInt32(cmd1.ExecuteScalar());
            i++;

        }
        catch (Exception ex)
        {
            i = 1;
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
            int cnt = 0;

            string filePath = FileUpload1.PostedFile.FileName;
            string filename = Path.GetFileName(filePath);
            string ext = Path.GetExtension(filename);
            string contenttype = String.Empty;
            string filePath1 = Server.MapPath("~/Uploads/") + Path.GetFileName(filePath);
            FileUpload1.PostedFile.SaveAs(filePath1);
            //Set the contenttype based on File Extension
            switch (ext)
            {
                case ".doc":
                    contenttype = "application/vnd.ms-word";
                    break;
                case ".docx":
                    contenttype = "application/vnd.ms-word";
                    break;
                case ".xls":
                    contenttype = "application/vnd.ms-excel";
                    break;
                case ".xlsx":
                    contenttype = "application/vnd.ms-excel";
                    break;
                case ".jpg":
                    contenttype = "image/jpg";
                    break;
                case ".png":
                    contenttype = "image/png";
                    break;
                case ".gif":
                    contenttype = "image/gif";
                    break;
                case ".pdf":
                    contenttype = "application/pdf";
                    break;
            }
            
            Random Password = new Random();
            int NewPassword = Password.Next(1000, 10000);
             
            String Name = Request.Form["fname"];
            String MName = Request.Form["mname"];
            String LName = Request.Form["lname"];
            String std = SelectedBranch.Text;
            String mobile = Request.Form["email"];
            String address = Request.Form["address"];
            String address1 = Request.Form["address1"];

            String edu = Request.Form["edu"];
            String spec = Request.Form["special"];
            String Role = DropDownList2.Text;
       

            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);



            con.Open();
            Stream fs = FileUpload1.PostedFile.InputStream;
            BinaryReader br = new BinaryReader(fs);
            Byte[] bytes = br.ReadBytes((Int32)fs.Length);


            string strQuery = "insert into CET_tbl_Teacher_Register1(id,Name, ContentType, Data,FirstName,MiddleName,LastName,branch,mobile,email,Password,Role,education,specialization,Address) values (@id,@Name,@ContentType,@Data,@FirstName,@MiddleName,@LastName,@branch,@mobile,@email,@Password,@Role,@education,@specialization,@address)";
            SqlCommand cmd = new SqlCommand(strQuery);
        cmd.Parameters.Add("@id", SqlDbType.Int).Value = i;
        cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = filename;
            cmd.Parameters.Add("@ContentType", SqlDbType.VarChar).Value = contenttype;
            cmd.Parameters.Add("@Data", SqlDbType.Binary).Value = bytes;

            cmd.Parameters.Add("@FirstName ", SqlDbType.VarChar).Value = Name;
            cmd.Parameters.Add("@MiddleName", SqlDbType.VarChar).Value = MName;
            cmd.Parameters.Add("@LastName", SqlDbType.VarChar).Value = LName;
            cmd.Parameters.Add("@branch", SqlDbType.VarChar).Value = std;

            cmd.Parameters.Add("@mobile", SqlDbType.VarChar).Value = mobile;
            cmd.Parameters.Add("@email", SqlDbType.VarChar).Value = address;
            cmd.Parameters.Add("@address", SqlDbType.VarChar).Value = address1;
            cmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = NewPassword;
            cmd.Parameters.Add("@Role", SqlDbType.VarChar).Value = Role;
            cmd.Parameters.Add("@education", SqlDbType.VarChar).Value = edu;
            cmd.Parameters.Add("@specialization", SqlDbType.VarChar).Value = spec;

            cmd.Connection = con;
            cmd.ExecuteNonQuery();

        try
        {
            try
            {
                MailMessage message = new MailMessage();
                message.From = new MailAddress("contact@ecssofttech.com");

                message.To.Add(new MailAddress(address));

                message.Subject = "Your Account Password And Other Details";
                message.Body = "Dear '" + Name + "' Your Username Is '" + mobile + "' And Password Is '" + NewPassword + "'";

                SmtpClient client = new SmtpClient();
                client.Host = "relay-hosting.secureserver.net";
                client.Port = 25;
                client.Send(message);

                Response.Write("Success");
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }


        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            //If the message failed at some point, let the user know
            //lblResult.Text = ex.ToString(); //alt text "Your message failed to send, please try again."
        }


        Response.Write("<script LANGUAGE= 'JavaScript' >alert ('Record Save Successfully')</Script>");


        SelectedBranch.Text = "";
        DropDownList1.SelectedIndex = -1;

    }

    protected void btnUpload_Click(object sender, EventArgs e)
    {

    }

    protected void rahul_Click(object sender, EventArgs e)
    {
        if (SelectedBranch.Text == "")
        {
            SelectedBranch.Text = DropDownList1.Text;
        }
        else
        {
            SelectedBranch.Text = SelectedBranch.Text + "," + DropDownList1.Text;           
        }
        firstname = Request.Form["fname"];
        middlename = Request.Form["mname"];
        lastname = Request.Form["lname"];
    }
}