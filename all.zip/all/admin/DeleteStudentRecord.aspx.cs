﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_DeleteStudentRecord : System.Web.UI.Page
{
    public string ExamID;

    public string id;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Session.Abandon();
            Response.Redirect("../Default.aspx");
        }


        string connectionString = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);

        if (!IsPostBack)
        {
            con.Open();
            SqlCommand cmd1 = new SqlCommand("Select Distinct(Exam_Name) from CET_QuestionPaperInfo1", con);
            cmd1.Connection = con;
            var obj1 = cmd1.ExecuteReader();
            while (obj1.Read())
            {
                DropDownList1.Items.Add(obj1.GetString(obj1.GetOrdinal("Exam_Name")));
            }
            obj1.Dispose();
            con.Close();

        }

        id = DropDownList1.Text;//int.Parse(Request.QueryString["id"]);

        con.Open();

        SqlCommand cmd2 = new SqlCommand("Select Exam_ID from CET_QuestionPaperInfo1 where Exam_Name = '" + id + "'", con);
        cmd2.Connection = con;
        id = cmd2.ExecuteScalar().ToString();

        DataTable dt1 = new DataTable();

        //string Query1 = "select a.id,a.ExamID,a.PRN,count(a.PRN),a.Name,a.TotalQuestions,a.SolvedQuestions,a.TotalMarks,a.ObtainedMarks from CET_StudentResult1 a INNER JOIN (SELECT DISTINCT PRN, MAX(SolvedQuestions) SolvedQuestions, MAX(id) id FROM CET_StudentResult1 b where ExamID = " + id + " GROUP BY PRN) b on a.id = b.id";
        string Query1 = "select b.Attempted 'Attempted (No Of Times)',a.ExamID,a.PRN,a.Seat_No,a.Name from CET_StudentResult1 a INNER JOIN (SELECT DISTINCT PRN,Count(PRN) Attempted, MAX(SolvedQuestions) SolvedQuestions, MAX(id) id FROM CET_StudentResult1 b where ExamID = " + id + " GROUP BY PRN) b on a.id = b.id order by b.Attempted DESC";

        SqlDataAdapter sda1 = new SqlDataAdapter(Query1, con);
        sda1.Fill(dt1);
        ExamID = id.ToString();
        abc.DataSource = dt1;
        abc.DataBind();

    }

    protected void abc_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "lnkbtnEdit")
        {
            int id1 = int.Parse(e.CommandArgument.ToString());

            string connectionString = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();

            SqlCommand cmd2 = new SqlCommand("Delete from CET_StudentResult1 where ExamID = '" + id + "' AND PRN = " + id1 + "", con);
            cmd2.ExecuteNonQuery();

            cmd2 = new SqlCommand("Delete from CET_Exam_AnswerSheet1 where PaperID = '" + id + "' AND PRN = " + id1 + "", con);
            cmd2.ExecuteNonQuery();

            DataTable dt1 = new DataTable();

            //string Query1 = "select a.id,a.ExamID,a.PRN,count(a.PRN),a.Name,a.TotalQuestions,a.SolvedQuestions,a.TotalMarks,a.ObtainedMarks from CET_StudentResult1 a INNER JOIN (SELECT DISTINCT PRN, MAX(SolvedQuestions) SolvedQuestions, MAX(id) id FROM CET_StudentResult1 b where ExamID = " + id + " GROUP BY PRN) b on a.id = b.id";
            string Query1 = "select b.Attempted 'Attempted (No Of Times)',a.ExamID,a.PRN,a.Seat_No,a.Name from CET_StudentResult1 a INNER JOIN (SELECT DISTINCT PRN,Count(PRN) Attempted, MAX(SolvedQuestions) SolvedQuestions, MAX(id) id FROM CET_StudentResult1 b where ExamID = " + id + " GROUP BY PRN) b on a.id = b.id order by b.Attempted DESC";

            SqlDataAdapter sda1 = new SqlDataAdapter(Query1, con);
            sda1.Fill(dt1);
            ExamID = id.ToString();
            abc.DataSource = dt1;
            abc.DataBind();

        }
    }


    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);

        id = DropDownList1.Text;//int.Parse(Request.QueryString["id"]);

        con.Open();

        SqlCommand cmd2 = new SqlCommand("Select Exam_ID from CET_QuestionPaperInfo1 where Exam_Name = '" + id + "'", con);
        cmd2.Connection = con;
        id = cmd2.ExecuteScalar().ToString();

        DataTable dt1 = new DataTable();

        //string Query1 = "select a.id,a.ExamID,a.PRN,count(a.PRN),a.Name,a.TotalQuestions,a.SolvedQuestions,a.TotalMarks,a.ObtainedMarks from CET_StudentResult1 a INNER JOIN (SELECT DISTINCT PRN, MAX(SolvedQuestions) SolvedQuestions, MAX(id) id FROM CET_StudentResult1 b where ExamID = " + id + " GROUP BY PRN) b on a.id = b.id";
        string Query1 = "select b.Attempted 'Attempted (No Of Times)',a.ExamID,a.PRN,a.Seat_No,a.Name from CET_StudentResult1 a INNER JOIN (SELECT DISTINCT PRN,Count(PRN) Attempted, MAX(SolvedQuestions) SolvedQuestions, MAX(id) id FROM CET_StudentResult1 b where ExamID = " + id + " GROUP BY PRN) b on a.id = b.id order by b.Attempted DESC";

        SqlDataAdapter sda1 = new SqlDataAdapter(Query1, con);
        sda1.Fill(dt1);
        ExamID = id.ToString();
        abc.DataSource = dt1;
        abc.DataBind();
    }
}