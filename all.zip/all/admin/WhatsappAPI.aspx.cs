﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Net;
using System.Net.Mail;

public partial class admin_StudRegister : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Session.Abandon();
            Response.Redirect("../Default.aspx");
        }

        //DropDownList1.Items.Clear();
        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);

        con.Open();
        SqlCommand cmd = new SqlCommand("Select Distinct(Name) from CET_branch1", con);
        cmd.Connection = con;
        var obj = cmd.ExecuteReader();
        while (obj.Read())
        {
        }
        obj.Dispose();
        con.Close();
          
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        String WNumber = Request.Form["WNumber"];
        String Token = Request.Form["Token"];
        String Instance = Request.Form["Instance"];

        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);

        con.Open();
        SqlCommand cmd = new SqlCommand("insert into CET_WhatsappAPI(WhatsappNumber,Token,Instance) values('" + WNumber + "','" + Token + "','" + Instance + "')", con);
        cmd.Connection = con;

        cmd.ExecuteNonQuery();
    }

}

