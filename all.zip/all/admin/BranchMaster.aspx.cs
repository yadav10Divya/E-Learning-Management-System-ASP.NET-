﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class back_end_Category : System.Web.UI.Page
{
    int i;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           getData();
        }

        try
        {

            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);

            con.Open();
            SqlCommand cmd1 = new SqlCommand("Select Max(Branch_ID) from CET_branch1 ", con);
            cmd1.Connection = con;

            i = 0;
            i = Convert.ToInt32(cmd1.ExecuteScalar());
            i++;

        }
        catch (Exception ex)
        {
            i = 1;
        }
    }
    public void getData()
    {
        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);

        con.Open();
        
        SqlDataAdapter da = new SqlDataAdapter("select Branch_ID,Name from CET_branch1", con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        grdView.DataSource = dt;
        grdView.DataBind();
    }

     
          


    protected void Button1_Click(object sender, EventArgs e)
    {
        //Access the File using the Name of HTML INPUT File.
       
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);
            var name = this.Request.Form["cat"];



            con.Open();
           

            //insert the file into database
            string strQuery = "insert into CET_branch1(Branch_ID,Name) values (@id,@Name)";
            SqlCommand cmd = new SqlCommand(strQuery);
        cmd.Parameters.Add("@id", SqlDbType.VarChar).Value = i;
        cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = name;
          
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            Response.Write("<script LANGUAGE='JavaScript' >alert('Added Successfull')</script>");
            getData();


    }

   

    protected void grdView_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /* This condition work when click on edit button */
        if (e.CommandName == "lnkbtnEdit")
        {
            int id = int.Parse(e.CommandArgument.ToString());
            Response.Redirect("UpdateData1.aspx?id=" + id); /* Pass id in querystring for updating record */
        }

      
        if (e.CommandName == "lnkbtnDelete")
        {
            int id = int.Parse(e.CommandArgument.ToString());
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);
            var name = this.Request.Form["cat"];

          
           SqlCommand cmd = new SqlCommand("delete from CET_branch1 where Branch_ID='" + id + "'", con);
           con.Open();
           cmd.ExecuteNonQuery();
           con.Close();
           getData(); /* Reload gridview */
        }
    }
}