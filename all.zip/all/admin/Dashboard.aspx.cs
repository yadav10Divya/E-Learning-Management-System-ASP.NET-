﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_Dashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Session.Abandon();
            Response.Redirect("../Default.aspx");
        }
    }
    public int Total_Staff(string tblName)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        con.Open();

        int Count = 0;

        SqlCommand cmd = new SqlCommand("select count(*) from " + tblName + "", con);

        Count = Convert.ToInt32(cmd.ExecuteScalar());

        return Count;
    }
    public int Std_Info(string std, string tblName)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        con.Open();

        int Count = 0;

        SqlCommand cmd = new SqlCommand("select count(*) from " + tblName + " where Branch='" + std + "'", con);

        Count = Convert.ToInt32(cmd.ExecuteScalar());

        return Count;
    }
    public int QuestionInfo(string std, string sName)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        con.Open();

        int Count = 0;

        SqlCommand cmd = new SqlCommand("select count(*) from CET_tbl_Question1 where Branch ='" + std + "' and Subject='" + sName + "'", con);

        Count = Convert.ToInt32(cmd.ExecuteScalar());

        return Count;
    }
}