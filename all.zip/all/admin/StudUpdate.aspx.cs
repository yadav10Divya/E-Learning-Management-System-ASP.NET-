﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_StudUpdate : System.Web.UI.Page
{
    public String StudentID = string.Empty;
    public String SFName = string.Empty;
    public String SMName = string.Empty;
    public String SLName = string.Empty;
    public String STD = string.Empty;
    public String seat = string.Empty;
    public String prn = string.Empty;
    public String year = string.Empty;
    public String sem = string.Empty;
    public String MNo = string.Empty;
    public String Address = string.Empty;


    protected void Page_Load(object sender, EventArgs e)
    {

        StudentID = Request.QueryString["Student_ID"];
        SFName = Request.QueryString["SFName"];
        SMName = Request.QueryString["SMName"];
        SLName = Request.QueryString["SLName"];
        STD = Request.QueryString["STD"];
        year = Request.QueryString["year"];
        prn = Request.QueryString["prn"];
        sem = Request.QueryString["sem"];
        MNo = Request.QueryString["MNo"];
        Address = Request.QueryString["Address"];
        seat = Request.QueryString["seat"];

        if (!IsPostBack)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);

            con.Open();
            SqlCommand cmd = new SqlCommand("Select Distinct(Name) from tbl_adbranch", con);
            cmd.Connection = con;
            var obj = cmd.ExecuteReader();
            while (obj.Read())
            {
                DropDownList1.Items.Add(obj.GetString(obj.GetOrdinal("Name")));
            }
            obj.Dispose();
            con.Close();

            GetData();


            int len = DropDownList1.Items.Count;

            for (int i = 0; i <= len - 1; i++)
            {
                if (DropDownList1.Items[i].Text == STD)
                {
                    DropDownList1.Items[i].Selected = true;
                }
            }
            len = DropDownList2.Items.Count;

            for (int i = 0; i <= len - 1; i++)
            {
                if (DropDownList2.Items[i].Text == year)
                {
                    DropDownList2.Items[i].Selected = true;
                }
            }
            len = DropDownList3.Items.Count;

            for (int i = 0; i <= len - 1; i++)
            {
                if (DropDownList3.Items[i].Text == sem)
                {
                    DropDownList3.Items[i].Selected = true;
                }
            }
        }


    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ToString();
        System.Data.SqlClient.SqlConnection con = new SqlConnection(connectionString);
        con.Open();
        String studentid = Request.Form["rollNo"];

        String Seat = Request.Form["seat"];
        String Prn = Request.Form["prn"];
        String Name = Request.Form["fname"];
        String MName = Request.Form["mname"];
        String LName = Request.Form["lname"];
        String std = DropDownList1.Text;
        String year = DropDownList2.Text;
        String sem = DropDownList3.Text;
        String mobile = Request.Form["mobile"];
        String address = Request.Form["email"];



        string Query = "Update Stud SET Stud_First_Name = '" + Name + "', Stud_Middle_Name ='" + MName + "', Stud_Last_Name= '" + LName + "', Branch = '" + std + "', Mobile_No='" + mobile + "', Address= '" + address + "', Seat_No= '" + Seat + "', PRN= '" + Prn + "', Year= '" + year + "', Semester= '" + sem + "' where Student_ID= " + StudentID + "";
        SqlCommand cmd = new SqlCommand(Query, con);
        cmd.ExecuteNonQuery();

        SqlCommand Query1 = new SqlCommand("select Password from stud where Student_ID= " + StudentID + "", con);
        var obj = Query1.ExecuteReader();


        if (obj.Read())
        {
            if (obj["Password"].ToString() == "")
            {
                Random Password = new Random();
                int NewPassword = Password.Next(1000, 10000);

                try
                {
                    Query = "Update Stud SET Password = '" + NewPassword + "' where Student_ID= " + StudentID + "";
                    cmd = new SqlCommand(Query, con);
                    cmd.ExecuteNonQuery();

                    MailMessage message = new MailMessage();
                    message.From = new MailAddress("contact@ecssofttech.com");

                    message.To.Add(new MailAddress(address));

                    message.Subject = "Your Account Details Are Updated";
                    message.Body = "Dear '" + Name + "', Your Account Details Are Updated! Your Username Is '" + mobile + "' And Password Is '" + NewPassword + "'";

                    SmtpClient client = new SmtpClient();
                    client.Host = "relay-hosting.secureserver.net";
                    client.Port = 25;
                    client.Send(message);

                    Response.Write("Success");
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }
            else
            {
                try
                {
                    MailMessage message = new MailMessage();
                    message.From = new MailAddress("contact@prabudhbharat.com");

                    message.To.Add(new MailAddress(address));

                    message.Subject = "Your Account Details Are Updated";
                    message.Body = "Dear '" + Name + "', Your Account Details Are Updated! Your Username Is '" + mobile + "' And Password Is '" + obj["Password"].ToString() + "'";

                    SmtpClient client = new SmtpClient();
                    client.Host = "relay-hosting.secureserver.net";
                    client.Port = 25;
                    client.Send(message);

                    Response.Write("Success");
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }
        }
        con.Close();


        Response.Write("<script language='javascript'>window.alert('Record Updated Successfully');window.location='StudList.aspx';</script>");
    }
    private void GetData()
    {
        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ToString();
        System.Data.SqlClient.SqlConnection con = new SqlConnection(connectionString);
        con.Open();
        SqlDataAdapter sda = new SqlDataAdapter("Select * from Stud", con);
        DataTable dt = new DataTable();
        sda.Fill(dt);


    }
    protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.GetData();
    }
}