﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Net;
using System.Net.Mail;

public partial class admin_StudRegister : System.Web.UI.Page
{
    public string eName = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Session.Abandon();
            Response.Redirect("../Default.aspx");
        }
        GetData();

    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    private void GetData()
    {

        string branch = Session["branch"].ToString();
        string year = Session["year"].ToString();
        string sem = Session["sem"].ToString();
        string subject = Session["subject"].ToString();
        eName = Session["Exam"].ToString();

        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ToString();
        SqlConnection con = new SqlConnection(connectionString);
        con.Open();
        string Query1 = "Select * from CET_Select_Exam_Question1 Where Branch = '" + branch + "' and Year = '" + year + "' and Semester = '" + sem + "' and Subject = '" + subject + "' order by Subject, Question_No";
        SqlDataAdapter sda1 = new SqlDataAdapter(Query1, con);
        DataTable dt = new DataTable();
        sda1.Fill(dt);
        grdView.DataSource = dt;
        grdView.DataBind();


    }
    protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdView.PageIndex = e.NewPageIndex;
        this.GetData();
    }
    protected void grdView_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "lnkbtnDelete")
        {
            string qid = e.CommandArgument.ToString();

            try
            {
                string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("Delete CET_tbl_Student_Register1 where Student_ID= '" + qid + "'");
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                Response.Write("<script LANGUAGE= 'JavaScript' >alert ('Record Delete Successfully')</Script>");
                GetData();
                con.Close();

            }
            catch (Exception ex)
            {

            }

        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
}

