﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_Upload_Question_Master : System.Web.UI.Page
{


    int Auto_Increment(string cmd1 , string str)
    {
        
        int cnt = 0;
        string connectionString = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = cmd1 ;
        cmd.Connection = con;
        cnt = Convert.ToInt32(cmd.ExecuteScalar());
        
        if (cnt > 0)
        {
            SqlCommand cmd2 = new SqlCommand();
            cmd2.CommandText = str;
            cmd2.Connection = con;
            cnt = Convert.ToInt32(cmd2.ExecuteScalar());
            cnt = cnt + 1;
        }
        else
        {
            cnt = cnt + 1;
        }
        cmd.Dispose();
        con.Close();
        return cnt;
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Session.Abandon();
            Response.Redirect("../Default.aspx");
        }
        if (!IsPostBack)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);
            try
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("Select Distinct(Name) from CET_branch1", con);
                cmd.Connection = con;
                var obj = cmd.ExecuteReader();
                while (obj.Read())
                {
                    DropDownList2.Items.Add(obj.GetString(obj.GetOrdinal("Name")));
                }
                obj.Dispose();
                con.Close();

                con.Open();
                cmd = new SqlCommand("Select Distinct(Subject_Name) from CET_tblSubject1", con);
                cmd.Connection = con;
                obj = cmd.ExecuteReader();
                while (obj.Read())
                {
                    DropDownList4.Items.Add(obj.GetString(obj.GetOrdinal("Subject_Name")));
                }
                obj.Dispose();
                con.Close();
            }
            catch (Exception ex)
            {

            }

            GetData();

        }
    }

    private void GetData()
    {
        try
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select * from CET_tbl_Question1", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            grdView.DataSource = dt;
            grdView.DataBind();
        }
        catch (Exception ex)
        {

        }
       
    }

    protected void grdView_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if(e.CommandName == "lnkbtnEdit")
        {
            string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
            string Standard = commandArgs[0];
            string Sub = commandArgs[1];
            string CNo = commandArgs[2];
            string CName= commandArgs[3];
            string QNo = commandArgs[4];
            string QName = commandArgs[5];
            string OptionA = commandArgs[6];
            string OptionB = commandArgs[7];
            string OptionC = commandArgs[8];
            string OptionD = commandArgs[9];
            string C_Ans = commandArgs[10];
            string Explanation = commandArgs[11];

            Response.Redirect("Update_UploadQuestion.aspx?Standard=" + Standard + " &Sub=" + Sub + " &CNo=" + CNo + " &CName=" + CName + " &QNo=" + QNo + " &QName=" + QName + " &OptionA=" + OptionA + " &OptionB=" + OptionB + " &OptionC=" + OptionC  + " &OptionD=" + OptionD + " &C_Ans=" + C_Ans + " &Explanation=" + Explanation);
            GetData();

        }

        if(e.CommandName == "lnkbtnDelete")
        {
            string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
            string Standard = commandArgs[0];
            string Sub = commandArgs[1];
            string QNo = commandArgs[2];
            string QID = commandArgs[3];

            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            String Query = "Delete CET_tbl_Question1 where Branch = '" + Standard + "' And Subject = '" + Sub + "' And Q_ID = '" + QID + "' And Question_No=" + Convert.ToInt32(QNo) + "";
            SqlCommand cmd = new SqlCommand(Query, con);
            cmd.ExecuteNonQuery();
            Response.Write("<script LANGUAGE= 'JavaScript' >alert ('Record Delete Successfully')</Script>");
            GetData();
            cmd.Dispose();
            con.Dispose();
            con.Close();
        }
    }

    protected void Save_Click(object sender, EventArgs e)
    {
        string filePath = null;
        string filename = null;
        byte[] bytes = null;
        string contenttype = null;
        int i = 0;

        string filePath2 = null;
        string filename2 = null;
        byte[] bytes2 = null;
        string contenttype2 = null;
        int i2 = 0;

        string filePath3 = null;
        string filename3 = null;
        byte[] bytes3 = null;
        string contenttype3 = null;
        int i3 = 0;

        string filePath4 = null;
        string filename4 = null;
        byte[] bytes4 = null;
        string contenttype4 = null;
        int i4 = 0;

        string filePath5 = null;
        string filename5 = null;
        byte[] bytes5 = null;
        string contenttype5 = null;
        int i5 = 0;

        string filePath6 = null;
        string filename6 = null;
        byte[] bytes6 = null;
        string contenttype6 = null;
        int i6 = 0;

        if (FileUpload1.HasFile)
        {
            i++;
            filePath = FileUpload1.PostedFile.FileName;
            filename = Path.GetFileName(filePath);
            string ext = Path.GetExtension(filename);
            contenttype = String.Empty;
            string filePath1 = Server.MapPath("~/Uploads/") + Path.GetFileName(filePath);
            FileUpload1.SaveAs(filePath1);
            //Set the contenttype based on File Extension
            switch (ext)
            {
                case ".doc":
                    contenttype = "application/vnd.ms-word";
                    break;
                case ".docx":
                    contenttype = "application/vnd.ms-word";
                    break;
                case ".xls":
                    contenttype = "application/vnd.ms-excel";
                    break;
                case ".xlsx":
                    contenttype = "application/vnd.ms-excel";
                    break;
                case ".jpg":
                    contenttype = "image/jpg";
                    break;
                case ".png":
                    contenttype = "image/png";
                    break;
                case ".gif":
                    contenttype = "image/gif";
                    break;
                case ".pdf":
                    contenttype = "application/pdf";
                    break;
            }

            Stream fs = FileUpload1.PostedFile.InputStream;
            BinaryReader br = new BinaryReader(fs);
            bytes = br.ReadBytes((Int32)fs.Length);

        }

        if (FileUpload2.HasFile)
        {
            i2++;
            filePath2 = FileUpload2.PostedFile.FileName;
            filename2 = Path.GetFileName(filePath2);
            string ext = Path.GetExtension(filename2);
            contenttype2 = String.Empty;
            string filePatha = Server.MapPath("~/Uploads/") + Path.GetFileName(filePath2);
            FileUpload2.SaveAs(filePatha);
            //Set the contenttype based on File Extension
            switch (ext)
            {
                case ".doc":
                    contenttype2 = "application/vnd.ms-word";
                    break;
                case ".docx":
                    contenttype2 = "application/vnd.ms-word";
                    break;
                case ".xls":
                    contenttype2 = "application/vnd.ms-excel";
                    break;
                case ".xlsx":
                    contenttype2 = "application/vnd.ms-excel";
                    break;
                case ".jpg":
                    contenttype2 = "image/jpg";
                    break;
                case ".png":
                    contenttype2 = "image/png";
                    break;
                case ".gif":
                    contenttype2 = "image/gif";
                    break;
                case ".pdf":
                    contenttype2 = "application/pdf";
                    break;
            }

            Stream fs = FileUpload2.PostedFile.InputStream;
            BinaryReader br = new BinaryReader(fs);
            bytes2 = br.ReadBytes((Int32)fs.Length);

        }
        if (FileUpload3.HasFile)
        {
            i3++;
            filePath3 = FileUpload3.PostedFile.FileName;
            filename3 = Path.GetFileName(filePath3);
            string ext = Path.GetExtension(filename3);
            contenttype3 = String.Empty;
            string filePathb = Server.MapPath("~/Uploads/") + Path.GetFileName(filePath3);
            FileUpload3.SaveAs(filePathb);
            //Set the contenttype based on File Extension
            switch (ext)
            {
                case ".doc":
                    contenttype3 = "application/vnd.ms-word";
                    break;
                case ".docx":
                    contenttype3 = "application/vnd.ms-word";
                    break;
                case ".xls":
                    contenttype3 = "application/vnd.ms-excel";
                    break;
                case ".xlsx":
                    contenttype3 = "application/vnd.ms-excel";
                    break;
                case ".jpg":
                    contenttype3 = "image/jpg";
                    break;
                case ".png":
                    contenttype3 = "image/png";
                    break;
                case ".gif":
                    contenttype3 = "image/gif";
                    break;
                case ".pdf":
                    contenttype3 = "application/pdf";
                    break;
            }

            Stream fs = FileUpload3.PostedFile.InputStream;
            BinaryReader br = new BinaryReader(fs);
            bytes3 = br.ReadBytes((Int32)fs.Length);

        }
        if (FileUpload4.HasFile)
        {
            i4++;
            filePath4 = FileUpload4.PostedFile.FileName;
            filename4 = Path.GetFileName(filePath4);
            string ext = Path.GetExtension(filename4);
            contenttype4 = String.Empty;
            string filePathc = Server.MapPath("~/Uploads/") + Path.GetFileName(filePath4);
            FileUpload4.SaveAs(filePathc);
            //Set the contenttype based on File Extension
            switch (ext)
            {
                case ".doc":
                    contenttype4 = "application/vnd.ms-word";
                    break;
                case ".docx":
                    contenttype4 = "application/vnd.ms-word";
                    break;
                case ".xls":
                    contenttype4 = "application/vnd.ms-excel";
                    break;
                case ".xlsx":
                    contenttype4 = "application/vnd.ms-excel";
                    break;
                case ".jpg":
                    contenttype4 = "image/jpg";
                    break;
                case ".png":
                    contenttype4 = "image/png";
                    break;
                case ".gif":
                    contenttype4 = "image/gif";
                    break;
                case ".pdf":
                    contenttype4 = "application/pdf";
                    break;
            }

            Stream fs = FileUpload4.PostedFile.InputStream;
            BinaryReader br = new BinaryReader(fs);
            bytes4 = br.ReadBytes((Int32)fs.Length);

        }
        if (FileUpload5.HasFile)
        {
            i5++;
            filePath5 = FileUpload5.PostedFile.FileName;
            filename5 = Path.GetFileName(filePath5);
            string ext = Path.GetExtension(filename5);
            contenttype5 = String.Empty;
            string filePathd = Server.MapPath("~/Uploads/") + Path.GetFileName(filePath5);
            FileUpload5.SaveAs(filePathd);
            //Set the contenttype based on File Extension
            switch (ext)
            {
                case ".doc":
                    contenttype5 = "application/vnd.ms-word";
                    break;
                case ".docx":
                    contenttype5 = "application/vnd.ms-word";
                    break;
                case ".xls":
                    contenttype5 = "application/vnd.ms-excel";
                    break;
                case ".xlsx":
                    contenttype5 = "application/vnd.ms-excel";
                    break;
                case ".jpg":
                    contenttype5 = "image/jpg";
                    break;
                case ".png":
                    contenttype5 = "image/png";
                    break;
                case ".gif":
                    contenttype5 = "image/gif";
                    break;
                case ".pdf":
                    contenttype5 = "application/pdf";
                    break;
            }

            Stream fs = FileUpload5.PostedFile.InputStream;
            BinaryReader br = new BinaryReader(fs);
            bytes5 = br.ReadBytes((Int32)fs.Length);

        }
        if (FileUpload6.HasFile)
        {
            i6++;
            filePath6 = FileUpload6.PostedFile.FileName;
            filename6 = Path.GetFileName(filePath6);
            string ext = Path.GetExtension(filename6);
            contenttype6 = String.Empty;
            string filePathe = Server.MapPath("~/Uploads/") + Path.GetFileName(filePath6);
            FileUpload6.SaveAs(filePathe);
            //Set the contenttype based on File Extension
            switch (ext)
            {
                case ".doc":
                    contenttype6 = "application/vnd.ms-word";
                    break;
                case ".docx":
                    contenttype6 = "application/vnd.ms-word";
                    break;
                case ".xls":
                    contenttype6 = "application/vnd.ms-excel";
                    break;
                case ".xlsx":
                    contenttype6 = "application/vnd.ms-excel";
                    break;
                case ".jpg":
                    contenttype6 = "image/jpg";
                    break;
                case ".png":
                    contenttype6 = "image/png";
                    break;
                case ".gif":
                    contenttype6 = "image/gif";
                    break;
                case ".pdf":
                    contenttype6 = "application/pdf";
                    break;
            }

            Stream fs = FileUpload6.PostedFile.InputStream;
            BinaryReader br = new BinaryReader(fs);
            bytes6 = br.ReadBytes((Int32)fs.Length);

        }

        int Number = Auto_Increment("Select Count(Q_ID) from CET_tbl_Question1 ", "Select Max(Q_ID) from CET_tbl_Question1 ");
            string connectionString = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();

        int j = 0;

        if(i == 1)
        {
            j = j | (i << 5);
        }
        if (i2 == 1)
        {
            j = j | (i2 << 4);
        }
        if (i3 == 1)
        {
            j = j | (i3 << 3);
        }
        if (i4 == 1)
        {
            j = j | (i4 << 2);
        }
        if (i5 == 1)
        {
            j = j | (i5 << 1);
        }
        if (i6 == 1)
        {
            j = j | (i6);
        }

        if(tb_Question_Name.Text == "")
        {
            tb_Question_Name.Text = filename;
        }
        if (tb_Option_A.Text == "")
        {
            tb_Option_A.Text = filename2;
        }
        if (tb_Option_B.Text == "")
        {
            tb_Option_B.Text = filename3;
        }
        if (tb_Option_C.Text == "")
        {
            tb_Option_C.Text = filename4;
        }
        if (tb_Option_D.Text == "")
        {
            tb_Option_D.Text = filename5;
        }
        if (tb_Correct_Ans.Text == "")
        {
            tb_Correct_Ans.Text = filename6;
        }


        string strQuery = "Insert into CET_tbl_Question1 (Branch,Subject,Year,Semester,Question_No,Question_Name,Option_A,Option_B,Option_C,Option_D,Correct_Ans,Explanation,Q_ID) values('" + DropDownList2.Text + "', '" + DropDownList4.Text + "','" + DropDownList3.Text + "','" + DropDownList1.Text + "'," + tb_Que_No.Text + ", '" + tb_Question_Name.Text + "', '" + tb_Option_A.Text + "', '" + tb_Option_B.Text + "', '" + tb_Option_C.Text + "', '" + tb_Option_D.Text + "', '" + tb_Correct_Ans.Text + "', '" + tb_Explaination.Text + "'," + Number + ")";
        SqlCommand cmd = new SqlCommand(strQuery);
        cmd.Connection = con;
        cmd.ExecuteNonQuery();

        if ((j & 32) == 32)
        {
            strQuery = "update CET_tbl_Question1 set ImgName =  @Name ,ContentType = @ContentType ,Data = @Data where Q_ID = '" + Number + "'";

            cmd = new SqlCommand(strQuery);

            cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = filename;
            cmd.Parameters.Add("@ContentType", SqlDbType.VarChar).Value = contenttype;
            cmd.Parameters.Add("@Data", SqlDbType.Binary).Value = bytes;

            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }
        if ((j & 16) == 16)
        {
            strQuery = "update CET_tbl_Question1 set ImgNameA =  @Name ,ContentTypeA = @ContentType ,DataA = @Data where Q_ID = '" + Number + "'";

            cmd = new SqlCommand(strQuery);

            cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = filename2;
            cmd.Parameters.Add("@ContentType", SqlDbType.VarChar).Value = contenttype2;
            cmd.Parameters.Add("@Data", SqlDbType.Binary).Value = bytes2;

            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }
        if ((j & 8) == 8)
        {
            strQuery = "update CET_tbl_Question1 set ImgNameB =  @Name ,ContentTypeB = @ContentType ,DataB = @Data where Q_ID = '" + Number + "'";

            cmd = new SqlCommand(strQuery);

            cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = filename3;
            cmd.Parameters.Add("@ContentType", SqlDbType.VarChar).Value = contenttype3;
            cmd.Parameters.Add("@Data", SqlDbType.Binary).Value = bytes3;

            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }
        if ((j & 4) == 4)
        {
            strQuery = "update CET_tbl_Question1 set ImgNameC =  @Name ,ContentTypeC = @ContentType ,DataC = @Data where Q_ID = '" + Number + "'";

            cmd = new SqlCommand(strQuery);

            cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = filename4;
            cmd.Parameters.Add("@ContentType", SqlDbType.VarChar).Value = contenttype4;
            cmd.Parameters.Add("@Data", SqlDbType.Binary).Value = bytes4;

            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }
        if ((j & 2) == 2)
        {
            strQuery = "update CET_tbl_Question1 set ImgNameD =  @Name ,ContentTypeD = @ContentType ,DataD = @Data where Q_ID = '" + Number + "'";

            cmd = new SqlCommand(strQuery);

            cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = filename5;
            cmd.Parameters.Add("@ContentType", SqlDbType.VarChar).Value = contenttype5;
            cmd.Parameters.Add("@Data", SqlDbType.Binary).Value = bytes5;

            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }
        if ((j & 1) == 1)
        {
            strQuery = "update CET_tbl_Question1 set ImgNameE =  @Name ,ContentTypeE = @ContentType ,DataE = @Data where Q_ID = '" + Number + "'";

            cmd = new SqlCommand(strQuery);

            cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = filename6;
            cmd.Parameters.Add("@ContentType", SqlDbType.VarChar).Value = contenttype6;
            cmd.Parameters.Add("@Data", SqlDbType.Binary).Value = bytes6;

            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        Response.Write("<script LANGUAGE='JavaSCript' > alert('Record Save Successfully')</script>");
            GetData();
            Clear_Control();


    }

    private void Clear_Control()
    {
                                           
        //dropdownlist_ChapterName.Text = "";
        tb_Que_No.Text = "";
        tb_Question_Name.Text = "";
        tb_Option_A.Text = "";
        tb_Option_B.Text = "";
        tb_Option_C.Text = "";
        tb_Option_D.Text = "";
        tb_Correct_Ans.Text = "";
        tb_Explaination.Text = "";
    }

    protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdView.PageIndex = e.NewPageIndex;
        this.GetData();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }

    protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
    {
        tb_Que_No.Text = Convert.ToString(Auto_Increment("Select Count(Question_No) from CET_tbl_Question1 where Branch = '" + DropDownList2.Text + "' And Subject = '" + DropDownList4.Text + "'And Semester = '" + DropDownList1.Text + "'And Year = '" + DropDownList3.Text + "'", "Select Max(Question_No) from CET_tbl_Question1 where Branch = '" + DropDownList2.Text + "' And Subject = '" + DropDownList4.Text + "'And Semester = '" + DropDownList1.Text + "'"));
    }
}
