﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_startexam1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Session.Abandon();
            Response.Redirect("../Default.aspx");
        }

        if (!IsPostBack)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);
            try
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("Select Distinct(Name) from CET_branch1", con);
                cmd.Connection = con;
                var obj = cmd.ExecuteReader();
                while (obj.Read())
                {
                    DropDownList2.Items.Add(obj.GetString(obj.GetOrdinal("Name")));
                }
                obj.Dispose();
                con.Close();
            }
            catch (Exception ex)
            {

            }
        }

    }


    protected void Btn_View_Click(object sender, EventArgs e)
    {

        Session["branch"] = DropDownList2.Text;
        Session["year"] = DropDownList3.Text;
        Session["sem"] = DropDownList4.Text;
        Session["subject"] = DropDownList1.Text;
        Session["marks"] = tb_TMarks.Text;
        Session["Time"] = tb_Time.Text;

        Response.Redirect("QDisplay.aspx");



    }
    protected void btn_Calculation_Click(object sender, EventArgs e)
    {



    }

    protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        try
        {
            DropDownList1.Items.Clear();
            con.Open();
            SqlCommand cmd = new SqlCommand("Select Distinct(Subject_Name) from CET_tblSubject1 where Branch = '" + DropDownList2.Text + "' and Year = '" + DropDownList3.Text + "' and Semester = '" + DropDownList4.Text + "'", con);
            cmd.Connection = con;
            var obj = cmd.ExecuteReader();
            while (obj.Read())
            {
                DropDownList1.Items.Add(obj.GetString(obj.GetOrdinal("Subject_Name")));
            }
            obj.Dispose();
            con.Close();
        }
        catch (Exception ex)
        {

        }
    }
}