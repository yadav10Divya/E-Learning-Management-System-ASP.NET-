﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_StaffUpdate : System.Web.UI.Page
{
    static int id;
    public string FirstName { get; private set; }
    public string MiddleName { get; private set; }
    public string LastName { get; private set; }
    public string branch { get; private set; }
    public string role { get; private set; }
    public string MobileNo { get; private set; }
    public string EmailID { get; private set; }
    public string path { get; private set; }
    public string Edu { get; private set; }
    public string spec { get; private set; }
    public string address { get; private set; }


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["id"] != null)
            {
                id = int.Parse(Request.QueryString["id"].ToString());
                string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
                SqlConnection con = new SqlConnection(connectionString);

                con.Open();

                string com = "Select * from CET_branch1";
                SqlDataAdapter adpt = new SqlDataAdapter(com, con);
                DataTable dt1 = new DataTable();
                adpt.Fill(dt1);
                DropDownList1.DataSource = dt1;
                DropDownList1.DataBind();
                DropDownList1.DataTextField = "Name";
                DropDownList1.DataValueField = "Name";
                DropDownList1.DataBind();

                SqlDataAdapter da = new SqlDataAdapter("Select * from CET_tbl_Teacher_Register1 where id ='" + id + "'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    FirstName = dt.Rows[0][4].ToString();
                    MiddleName = dt.Rows[0][5].ToString();
                    LastName = dt.Rows[0][6].ToString();
                    branch = dt.Rows[0][7].ToString();
                    MobileNo = dt.Rows[0][8].ToString();
                    EmailID = dt.Rows[0][9].ToString();
                    Edu = dt.Rows[0][12].ToString();
                    spec = dt.Rows[0][13].ToString();
                    address = dt.Rows[0][14].ToString();
                    byte[] imagem = (byte[])(dt.Rows[0][3]);
                    path = Convert.ToBase64String(imagem);
                    img1.ImageUrl = "data:image/jpg;base64," + path ;
                    role = dt.Rows[0][11].ToString();                    
                }
            }
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        int cnt = 0;
        string filePath = "";
        string filename = "";
        string contenttype = "";
        Byte[] bytes = null;

        if (FileUpload1.PostedFile.FileName != "")
        {
            cnt++;
            filePath = FileUpload1.PostedFile.FileName;
            filename = Path.GetFileName(filePath);
            string ext = Path.GetExtension(filename);
            contenttype = String.Empty;
            string filePath1 = Server.MapPath("~/Uploads/") + Path.GetFileName(filePath);
            FileUpload1.SaveAs(filePath1);
            //Set the contenttype based on File Extension
            switch (ext)
            {
                case ".doc":
                    contenttype = "application/vnd.ms-word";
                    break;
                case ".docx":
                    contenttype = "application/vnd.ms-word";
                    break;
                case ".xls":
                    contenttype = "application/vnd.ms-excel";
                    break;
                case ".xlsx":
                    contenttype = "application/vnd.ms-excel";
                    break;
                case ".jpg":
                    contenttype = "image/jpg";
                    break;
                case ".png":
                    contenttype = "image/png";
                    break;
                case ".gif":
                    contenttype = "image/gif";
                    break;
                case ".pdf":
                    contenttype = "application/pdf";
                    break;
            }
            Stream fs = FileUpload1.PostedFile.InputStream;
            BinaryReader br = new BinaryReader(fs);
            bytes = br.ReadBytes((Int32)fs.Length);

        }



        Random Password = new Random();
        int NewPassword = Password.Next(1000, 10000);


        String Name = Request.Form["fname"];
        String MName = Request.Form["mname"];
        String LName = Request.Form["lname"];
        String std = DropDownList1.Text;
        String mobile = Request.Form["email"];
        String address = Request.Form["address"];
        String Role = DropDownList3.Text;
        String address1 = Request.Form["address1"];
        String edu = Request.Form["edu"];
        String spec1 = Request.Form["special"];

        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);



        con.Open();


        SqlCommand cmd = new SqlCommand();
        if (cnt != 0)
        {
         cmd.CommandText = "Update CET_tbl_Teacher_Register1 set Name='" + filename + "',ContentType='" + contenttype + "', Data= @Data ,FirstName='" + Name + "',MiddleName='" + MName + "',LastName='" + LName + "',branch='" + std + "',mobile='" + mobile + "',email='" + address + "',Password='" + NewPassword + "',Role='" + Role + "',education='" + edu + "',specialization='" + spec1 + "',Address= '" + address1 + "' where id ='" + id + "'";
         cmd.Parameters.Add("@Data", SqlDbType.Binary).Value = bytes;
        }
        else
        { 
        cmd.CommandText = "Update CET_tbl_Teacher_Register1 set FirstName='" + Name + "',MiddleName='" + MName + "',LastName='" + LName + "',branch='" + std + "',mobile='" + mobile + "',email='" + address + "',Password='" + NewPassword + "',Role='" + Role + "',education='" + edu + "',specialization='" + spec1 + "',Address= '" + address1 + "' where id ='" + id + "'";
        }
        //string strQuery = "insert into Staff(Name, ContentType, Data,FirstName,MiddleName,LastName,branch,mobile,email,Password,Role) values (@Name, @ContentType,@Data,@FirstName,@MiddleName,@LastName,@branch,@mobile,@email,@Password,@Role )";

        cmd.Connection = con;
            cmd.ExecuteNonQuery();


        try
        {
            try
            {
                MailMessage message = new MailMessage();
                message.From = new MailAddress("contact@ecssofttech.com");

                message.To.Add(new MailAddress(address));

                message.Subject = "Your Account Password And Other Details";
                message.Body = "Dear '" + Name + "' Your Username Is '" + mobile + "' And Password Is '" + NewPassword + "'";

                SmtpClient client = new SmtpClient();
                client.Host = "relay-hosting.secureserver.net";
                client.Port = 25;
                client.Send(message);

                Response.Write("Success");
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
            }


        }
        catch (Exception ex)
        {
            //Response.Write(ex.Message);
            //If the message failed at some point, let the user know
            //lblResult.Text = ex.ToString(); //alt text "Your message failed to send, please try again."
        }

        Response.Write("<script language='javascript'>window.alert('Record Updated Successfully '); window.location='StaffEdit.aspx';</script>");

     

    }
}
