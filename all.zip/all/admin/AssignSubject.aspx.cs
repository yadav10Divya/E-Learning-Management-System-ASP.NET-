﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class back_end_Category : System.Web.UI.Page
{

    //int i;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           getData();
        }

        //try
        //{
        //    string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        //    SqlConnection con = new SqlConnection(connectionString);


        //    con.Open();
        //    SqlCommand cmd1 = new SqlCommand("Select Max(id) from CET_AssignSubject ", con);
        //    cmd1.Connection = con;

        //    i = 0;
        //    i = Convert.ToInt32(cmd1.ExecuteScalar());
        //    i++;

        //}
        //catch (Exception ex)
        //{
        //    i = 1;
        //}
     
    }
    public void getData()
    {
        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        try
        {
            DropDownList1.Items.Clear();
            DropDownList3.Items.Clear();
            DropDownList2.Items.Clear();

            con.Open();
            SqlCommand cmd = new SqlCommand("Select Name from CET_branch1", con);
            cmd.Connection = con;
            var obj = cmd.ExecuteReader();
            while (obj.Read())
            {
                DropDownList2.Items.Add(obj.GetString(obj.GetOrdinal("Name")));
            }
            obj.Dispose();
            con.Close();

            con.Open();
            cmd = new SqlCommand("Select Subject_Name from CET_tblSubject1 where Branch = '" + DropDownList2.Text + "' and Year = '" + DropDownList4.Text + "'", con);
            cmd.Connection = con;
            obj = cmd.ExecuteReader();
            while (obj.Read())
            {
                DropDownList1.Items.Add(obj.GetString(obj.GetOrdinal("Subject_Name")));
            }
            obj.Dispose();
            con.Close();

            con.Open();
            cmd = new SqlCommand("Select * from CET_tbl_Teacher_Register1 order by id", con);
            cmd.Connection = con;
            obj = cmd.ExecuteReader();
            while (obj.Read())
            {
                DropDownList3.Items.Add(obj["id"].ToString() + " " + obj["FirstName"].ToString() + " " + obj["MiddleName"].ToString() + " " + obj["LastName"].ToString());
            }
            obj.Dispose();
            con.Close();
        }
        catch (Exception ex)
        {

        }


        con.Open();

        //SqlDataAdapter da = new SqlDataAdapter("select id,Cat_Name,Data from tblFiles1", con);
        SqlDataAdapter da = new SqlDataAdapter("select * from CET_AssignSubject", con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        grdView.DataSource = dt;
        grdView.DataBind();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string str = "";

        string id = DropDownList3.Text.Split(' ')[0];

        string name = DropDownList3.Text.Split(' ')[1] + " " + DropDownList3.Text.Split(' ')[2] + " " + DropDownList3.Text.Split(' ')[3];

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConString"].ConnectionString);

        SqlDataAdapter da = new SqlDataAdapter("Select Subjects from CET_AssignSubject where Name = '" + name + "' and Branch = '" + DropDownList2.Text + "' and Year = '" + DropDownList4.Text + "'", con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            if (dt.Rows[0][0].ToString() != "")
            {
                str = dt.Rows[0][0].ToString();

                str = str + "," + DropDownList1.Text;

            }
            else
            {
                str = DropDownList1.Text;
            }
            con.Open();
            string strQuery = "update CET_AssignSubject set Name = @Name ,Subjects = @Subjects where Name = '" + name + "'";
            SqlCommand cmd = new SqlCommand(strQuery);
            cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = name;
            cmd.Parameters.Add("@Subjects", SqlDbType.VarChar).Value = str;

            cmd.Connection = con;
            cmd.ExecuteNonQuery();

        }
        else
        {
            str = DropDownList1.Text;

            con.Open();
            string strQuery = "insert into CET_AssignSubject(id,Name,Subjects,Branch,Year) values(@id,@Name,@Subjects,@Branch,@Year)";
            SqlCommand cmd = new SqlCommand(strQuery);
            //cmd.Parameters.Add("@id", SqlDbType.VarChar).Value = i;
            cmd.Parameters.Add("@id", SqlDbType.VarChar).Value = id;
            cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = name;
            cmd.Parameters.Add("@Subjects", SqlDbType.VarChar).Value = str;
            cmd.Parameters.Add("@Branch", SqlDbType.VarChar).Value = DropDownList2.Text;
            cmd.Parameters.Add("@Year", SqlDbType.VarChar).Value = DropDownList4.Text;

            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        Response.Write("<script LANGUAGE='JavaScript' >alert('Added Successfull')</script>");
        getData();

    }


    protected void grdView_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /* This condition work when click on edit button */
        string[] arr = e.CommandArgument.ToString().Split(',');
        string id = arr[0];
        string year = arr[1];
        string branch = arr[2];

        if (e.CommandName == "lnkbtnEdit")
        {
            Response.Redirect("EditSubject.aspx?Subject_ID=" + id); /* Pass id in querystring for updating record */
            //Response.Redirect("UpdateData.aspx?Subject_Name = name ");
            getData();
        }

        /* This condition work when click on delete button */
        if (e.CommandName == "lnkbtnDelete")
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConString"].ConnectionString);

            //SqlCommand cmd = new SqlCommand("delete from tblFiles1 where ID='" + id + "'", con);
            SqlCommand cmd = new SqlCommand("delete from CET_AssignSubject where Name='" + id + "' and Branch = '" + branch + "' and Year = '" + year + "'", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            getData(); /* Reload gridview */
        }
    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);

        DropDownList1.Items.Clear();

        con.Open();
        SqlCommand cmd = new SqlCommand("Select Subject_Name from CET_tblSubject1 where Branch = '" + DropDownList2.Text + "' and Year = '" + DropDownList4.Text + "'", con);
        cmd.Connection = con;
        var obj = cmd.ExecuteReader();
        while (obj.Read())
        {
            DropDownList1.Items.Add(obj.GetString(obj.GetOrdinal("Subject_Name")));
        }
        obj.Dispose();
        con.Close();
    }
}