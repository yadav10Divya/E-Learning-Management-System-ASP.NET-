﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_Notice : System.Web.UI.Page
{
    int i;
    int j;
    int k;
    public List<string> list1 = new List<string>();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);

            con.Open();

            SqlCommand cmd = new SqlCommand("Select Name from CET_branch1", con);
            cmd.Connection = con;
            var obj = cmd.ExecuteReader();
            while (obj.Read())
            {
                DropDownList2.Items.Add(obj["Name"].ToString());
            }
            obj.Dispose();
            con.Close();
            DropDownList2.Items.Insert(0, new ListItem("All"));

            DropDownList2.Enabled = false;
            DropDownList3.Enabled = false;
            DropDownList4.Enabled = false;
        }


        try
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);


            con.Open();
            SqlCommand cmd1 = new SqlCommand("Select Max(id) from CET_NoticeForSingleStudent ", con);
            cmd1.Connection = con;

            i = 0;
            i = Convert.ToInt32(cmd1.ExecuteScalar());
            i++;

        }
        catch (Exception ex)
        {
            i = 1;
        }


        try
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);


            con.Open();
            SqlCommand cmd1 = new SqlCommand("Select Max(id) from CET_NoticeForSingleStaff ", con);
            cmd1.Connection = con;

            j = 0;
            j = Convert.ToInt32(cmd1.ExecuteScalar());
            j++;

        }
        catch (Exception ex)
        {
            j = 1;
        }

        try
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);


            con.Open();
            SqlCommand cmd1 = new SqlCommand("Select Max(id) from CET_Notice ", con);
            cmd1.Connection = con;

           k = 0;
            k = Convert.ToInt32(cmd1.ExecuteScalar());
            k++;

        }
        catch (Exception ex)
        {
            k = 1;
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        string Notice = Request.Form["notice"];
        string Category = DropDownList1.Text;
        string Branch = DropDownList2.Text;
        string Send = DropDownList3.Text;
        string Name = (DropDownList4.Text != "")? DropDownList4.Text.Split(' ')[0] : DropDownList4.Text;

        if (Notice != "" && Branch != "" && Name != "")
        {
            string instance = "";
            string token = "";
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);

            con.Open();

            SqlCommand cmd2 = new SqlCommand("select * from CET_WhatsappAPI where id = 1", con);
            var obj1 = cmd2.ExecuteReader();
            while (obj1.Read())
            {
                instance = obj1["Instance"].ToString();
                token = obj1["Token"].ToString();
            }
            obj1.Dispose();

            if (Category == "All")
            {
                SqlCommand cmd = new SqlCommand("insert into CET_Notice(id,Branch,Notice,Notice_From,Category) values(@id,@Branch,@Notice,@From,@Category)", con);
                cmd.Parameters.Add("@id ", SqlDbType.VarChar).Value = k;
                cmd.Parameters.Add("@Notice ", SqlDbType.VarChar).Value = Notice;
                cmd.Parameters.Add("@Branch ", SqlDbType.VarChar).Value = Branch;
                cmd.Parameters.Add("@From ", SqlDbType.VarChar).Value = "Admin";
                cmd.Parameters.Add("@Category ", SqlDbType.VarChar).Value = Category;

                cmd.ExecuteNonQuery();

                SqlCommand cmd1 = new SqlCommand("select mobile from CET_tbl_Teacher_Register1 where branch = '" + Branch + "'", con);
                var obj = cmd1.ExecuteReader();

                while (obj.Read())
                {
                    string Number = obj["mobile"].ToString();

                    //string json1 = (new WebClient()).DownloadString("https://api.chat-api.com/instance" + instance + "/sendMessage?token=" + token + "&phone=91'" + Number + "'&body=" + Notice + "");

                }
                obj.Dispose();

                cmd1 = new SqlCommand("select Mobile_No from CET_tbl_Student_Register1 where Branch = '" + Branch + "'", con);
                obj = cmd1.ExecuteReader();

                while (obj.Read())
                {
                    string Number = obj["Mobile_No"].ToString();

                    //string json1 = (new WebClient()).DownloadString("https://api.chat-api.com/instance" + instance + "/sendMessage?token=" + token + "&phone=91'" + Number + "'&body=" + Notice + "");

                }
                

            }
            else if (Category == "Staff")
            {


                if (Send == "All")
                {
                    SqlCommand cmd = new SqlCommand("insert into CET_Notice(id,Branch,Notice,Notice_From,Category) values(@id,@Branch,@Notice,@From,@Category)",con);
                    cmd.Parameters.Add("@id ", SqlDbType.VarChar).Value = k;
                    cmd.Parameters.Add("@Notice ", SqlDbType.VarChar).Value = Notice;
                    cmd.Parameters.Add("@Branch ", SqlDbType.VarChar).Value = Branch;
                    cmd.Parameters.Add("@From ", SqlDbType.VarChar).Value = "Admin";
                    cmd.Parameters.Add("@Category ", SqlDbType.VarChar).Value = Category;

                    cmd.ExecuteNonQuery();

                    SqlCommand cmd1 = new SqlCommand("select mobile from CET_tbl_Teacher_Register1 where branch = '" + Branch + "'", con);
                    var obj = cmd1.ExecuteReader();

                    while (obj.Read())
                    {
                        string Number = obj["mobile"].ToString();

                        //string json1 = (new WebClient()).DownloadString("https://api.chat-api.com/instance" + instance + "/sendMessage?token=" + token + "&phone=91'" + Number + "'&body=" + Notice + "");

                    }
                }
                else
                {
                    
                    //string branch = DropDownList2.Text;

                    //SqlCommand cmds = new SqlCommand("select branch from CET_tbl_Teacher_Register1",con);
                    //var objs = cmds.ExecuteReader();

                    //int i = 0;
                    //while(objs.Read())
                    //{
                    //    string branchlist = objs["branch"].ToString();

                    //    //if(branchlist == )
                    //    //{
                            
                    //    //}

                    //    i++;
                    //}

                    //con.Close();

                    //con.Open();
                    SqlCommand cmd = new SqlCommand("insert into CET_NoticeForSingleStaff(id,Name,Branch,Notice,Notice_From) values(@id,@Name,@Branch,@Notice,'Admin')", con);
                    cmd.Parameters.Add("@id ", SqlDbType.VarChar).Value = j;
                    cmd.Parameters.Add("@Notice ", SqlDbType.VarChar).Value = Notice;
                    cmd.Parameters.Add("@Name ", SqlDbType.VarChar).Value = Name;
                    cmd.Parameters.Add("@Branch ", SqlDbType.VarChar).Value = Branch;

                    cmd.ExecuteNonQuery();

                    SqlCommand cmd1 = new SqlCommand("select mobile from CET_tbl_Teacher_Register1 where id = '" + Name + "'", con);
                    var obj = cmd1.ExecuteReader();

                    while (obj.Read())
                    {
                        string Number = obj["mobile"].ToString();

                        //string json1 = (new WebClient()).DownloadString("https://api.chat-api.com/instance" + instance + "/sendMessage?token=" + token + "&phone=91'" + Number + "'&body=" + Notice + "");

                    }
                }
            }
            else if (Category == "Student")
            {
                if (Send == "All")
                {
                    SqlCommand cmd = new SqlCommand("insert into CET_Notice(id,Branch,Notice,Notice_From,Category) values(@id,@Branch,@Notice,@From,@Category)", con);
                    cmd.Parameters.Add("@id ", SqlDbType.VarChar).Value = k;
                    cmd.Parameters.Add("@Notice ", SqlDbType.VarChar).Value = Notice;
                    cmd.Parameters.Add("@Branch ", SqlDbType.VarChar).Value = Branch;
                    cmd.Parameters.Add("@From ", SqlDbType.VarChar).Value = "Admin";
                    cmd.Parameters.Add("@Category ", SqlDbType.VarChar).Value = Category;

                    cmd.ExecuteNonQuery();

                    SqlCommand cmd1 = new SqlCommand("select Mobile_No from CET_tbl_Student_Register1 where Branch = '" + Branch + "'", con);
                    var obj = cmd1.ExecuteReader();

                    while (obj.Read())
                    {
                        string Number = obj["Mobile_No"].ToString();

                        //string json1 = (new WebClient()).DownloadString("https://api.chat-api.com/instance" + instance + "/sendMessage?token=" + token + "&phone=91'" + Number + "'&body=" + Notice + "");

                    }
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("insert into CET_NoticeForSingleStudent(id,Name,Branch,Notice,Notice_From) values(@id,@Name,@Branch,@Notice,'Admin')", con);
                    cmd.Parameters.Add("@id ", SqlDbType.VarChar).Value = i;
                    cmd.Parameters.Add("@Notice ", SqlDbType.VarChar).Value = Notice;
                    cmd.Parameters.Add("@Name ", SqlDbType.VarChar).Value = Name;
                    cmd.Parameters.Add("@Branch ", SqlDbType.VarChar).Value = Branch;

                    cmd.ExecuteNonQuery();

                    SqlCommand cmd1 = new SqlCommand("select Mobile_No from CET_tbl_Student_Register1 where Student_ID = '" + Name + "'", con);
                    var obj = cmd1.ExecuteReader();

                    while (obj.Read())
                    { 
                        string Number = obj["Mobile_No"].ToString();

                       //string json1 = (new WebClient()).DownloadString("https://api.chat-api.com/instance" + instance + "/sendMessage?token=" + token + "&phone=91'" + Number + "'&body=" + Notice + "");

                    }
                }
            }
            con.Close();

            Response.Write("<script LANGUAGE= 'JavaScript' >alert ('Notice Send Successfully')</Script>");
        }
    }
    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList3.Text == "All")
        {
            DropDownList4.SelectedIndex = 0;
            DropDownList4.Enabled = false;
        }
        else
        {
            DropDownList4.Enabled = true;

            DropDownList4.Items.Clear();
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);

            con.Open();

            string TName = "";
            string TBranch = "";
            if (DropDownList1.Text == "Staff")
            {
                TName = "CET_tbl_Teacher_Register1";
                TBranch = DropDownList2.Text;

                SqlCommand cmd = new SqlCommand("Select * from " + TName + " where branch LIKE '%"+ TBranch +"%' ", con);
                cmd.Connection = con;
                var obj = cmd.ExecuteReader();
                while (obj.Read())
                {
                    DropDownList4.Items.Add(obj["id"].ToString() + " " + obj["FirstName"].ToString() + " " + obj["MiddleName"].ToString() + " " + obj["LastName"].ToString());
                }
            }
            else
            {
                TName = "CET_tbl_Student_Register1";

                SqlCommand cmd = new SqlCommand("Select * from " + TName + " where branch = '" + DropDownList2.Text + "'", con);
                cmd.Connection = con;
                var obj = cmd.ExecuteReader();
                while (obj.Read())
                {
                    DropDownList4.Items.Add(obj["Student_ID"].ToString() + " " + obj["Stud_First_Name"].ToString() + " " + obj["Stud_Middle_Name"].ToString() + " " + obj["Stud_Last_Name"].ToString());
                }

            }
            con.Close();
        }
    }

    protected void DropDownList1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        if (DropDownList1.Text == "All")
        {
            DropDownList2.SelectedIndex = 0;
            DropDownList2.Enabled = false;

            DropDownList3.SelectedIndex = 0;
            DropDownList3.Enabled = false;

            DropDownList4.Items.Insert(0, new ListItem("All", "-1"));
            DropDownList4.SelectedIndex = 0;
            DropDownList4.Enabled = false;
        }
        else
        {
            DropDownList2.Enabled = true;

            DropDownList3.SelectedIndex = 0;
            DropDownList3.Enabled = false;

            DropDownList4.Items.Insert(0, new ListItem("All", "-1"));
            DropDownList4.SelectedIndex = 0;
            DropDownList4.Enabled = false;
        }
    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList2.Text == "All")
        {
            DropDownList3.SelectedIndex = 0;
            DropDownList3.Enabled = false;

            DropDownList4.Items.Insert(0, new ListItem("All", "-1"));
            DropDownList4.SelectedIndex = 0;
            DropDownList4.Enabled = false;
        }
        else
        {
            DropDownList3.SelectedIndex = 0;
            DropDownList3.Enabled = true;

            DropDownList4.Items.Insert(0, new ListItem("All", "-1"));
            DropDownList4.SelectedIndex = 0;
            DropDownList4.Enabled = false;
        }
    }
}