﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_BulkUpload : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        //Upload and save the file
        string excelPath = Server.MapPath("~/CSV/") + Path.GetFileName(FileUpload1.PostedFile.FileName);
        FileUpload1.SaveAs(excelPath);

        string conString = string.Empty;
        string extension = Path.GetExtension(FileUpload1.PostedFile.FileName);
        switch (extension)
        {
            case ".xls": //Excel 97-03
                conString = ConfigurationManager.ConnectionStrings["Excel03ConString"].ConnectionString;
                break;
            case ".xlsx": //Excel 07 or higher
                conString = ConfigurationManager.ConnectionStrings["Excel07+ConString"].ConnectionString;
                break;

        }
        conString = string.Format(conString, excelPath);
        using (OleDbConnection excel_con = new OleDbConnection(conString))
        {
            excel_con.Open();
            string sheet1 = excel_con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null).Rows[0]["TABLE_NAME"].ToString();
            DataTable dtExcelData = new DataTable();

            //[OPTIONAL]: It is recommended as otherwise the data will be considered as String by default.
            dtExcelData.Columns.AddRange(new DataColumn[11] {

             
                new DataColumn("Stud_First_Name", typeof(string)),
                new DataColumn("Stud_Middle_Name", typeof(string)),
                 new DataColumn("Stud_Last_Name", typeof(string)),
                  new DataColumn("Branch", typeof(string)),
                   new DataColumn("Mobile_No", typeof(string)),
                    new DataColumn("Address", typeof(string)),
                     new DataColumn("Password", typeof(string)),
                      new DataColumn("Seat_No", typeof(string)),
                       new DataColumn("PRN", typeof(string)),
                        new DataColumn("Year", typeof(string)),
                         new DataColumn("Semester", typeof(string))

            });

            using (OleDbDataAdapter oda = new OleDbDataAdapter("SELECT * FROM [" + sheet1 + "]", excel_con))
            {
                oda.Fill(dtExcelData);
            }
                excel_con.Close();

            string consString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(consString))
            {
                using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(con))
                {
                    //Set the database table name
                    sqlBulkCopy.DestinationTableName = "CET_tbl_Student_Register1";

                    //[OPTIONAL]: Map the Excel columns with that of the database table
                   
                    sqlBulkCopy.ColumnMappings.Add("Stud_First_Name", "Stud_First_Name");
                    sqlBulkCopy.ColumnMappings.Add("Stud_Middle_Name", "Stud_Middle_Name");
                    sqlBulkCopy.ColumnMappings.Add("Stud_Last_Name", "Stud_Last_Name");
                    sqlBulkCopy.ColumnMappings.Add("Branch", "Branch");
                    sqlBulkCopy.ColumnMappings.Add("Mobile_No", "Mobile_No");
                    sqlBulkCopy.ColumnMappings.Add("Address", "Address");
                    sqlBulkCopy.ColumnMappings.Add("Password", "Password");
                    sqlBulkCopy.ColumnMappings.Add("PRN", "PRN");
                    sqlBulkCopy.ColumnMappings.Add("Year", "Year");
                    sqlBulkCopy.ColumnMappings.Add("Semester", "Semester");
                   
                    con.Open();
                    sqlBulkCopy.WriteToServer(dtExcelData);
                    con.Close();
                }
            }
        }

    }

    private void InsertCSVRecords(DataTable csvdt)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);



        con.Open();

        //creating object of SqlBulkCopy  
        SqlBulkCopy objbulk = new SqlBulkCopy(con);
        //assigning Destination table name  
        objbulk.DestinationTableName = "CET_tbl_Student_Register1";
        //Mapping Table column  
        objbulk.ColumnMappings.Add("Student_ID", "Student_ID");
        objbulk.ColumnMappings.Add("Stud_First_Name", "Stud_First_Name");
        objbulk.ColumnMappings.Add("Stud_Middle_Name", "Stud_Middle_Name");
        objbulk.ColumnMappings.Add("Stud_Last_Name", "Stud_Last_Name");
        objbulk.ColumnMappings.Add("Branch", "Branch");
        objbulk.ColumnMappings.Add("Mobile_No", "Mobile_No");
        objbulk.ColumnMappings.Add("Address", "Address");
        objbulk.ColumnMappings.Add("Password", "Password");
        objbulk.ColumnMappings.Add("Seat_No", "Seat_No");
        objbulk.ColumnMappings.Add("PRN", "PRN");
        objbulk.ColumnMappings.Add("Year", "Year");
        objbulk.ColumnMappings.Add("Semester", "Semester");
        //inserting Datatable Records to DataBase  

        objbulk.WriteToServer(csvdt);
        con.Close();


    }

    protected void Button2_Click(object sender, EventArgs e)
    {

    }
}