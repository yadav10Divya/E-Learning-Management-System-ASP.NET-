﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class admin_QDisplay : System.Web.UI.Page
{
    public static string Que_Paper_Id = null;

    public static string QueId = null;

    public static int i = 0;

    public static string Time;
    int AutoIncrement()
    {
        int Cnt = 0;

        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand("Select Count(Exam_ID) from CET_QuestionPaperInfo1", con);
        Cnt = Convert.ToInt32(cmd.ExecuteScalar());
        if (Cnt > 0)
        {
            SqlCommand cmd1 = new SqlCommand("Select Max(Exam_ID) from CET_QuestionPaperInfo1", con);
            Cnt = Convert.ToInt32(cmd1.ExecuteScalar());
            Cnt += 1;
        }
        else
        {
            Cnt = 1;
        }

        return Cnt;
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Session.Abandon();
            Response.Redirect("../Default.aspx");
        }
        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        con.Open();
        DataTable dt = new DataTable();

        string branch = Session["branch"].ToString();
        string year = Session["year"].ToString();
        string sem = Session["sem"].ToString();
        string subject = Session["subject"].ToString();
        string TotalMarks = Session["marks"].ToString();

        Time = Session["Time"].ToString();
        Que_Paper_Id = Convert.ToString(AutoIncrement());


        string Query1 = "Select * from CET_tbl_Question1 Where Branch = '" + branch + "' and Year = '" + year + "' and Semester = '" + sem + "' and Subject = '" + subject + "' order by Subject, Question_No";
        SqlDataAdapter sda1 = new SqlDataAdapter(Query1, con);
        sda1.Fill(dt);
        abc.DataSource = dt;
        abc.DataBind();


    }


    protected void grdView_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "lnkbtnDelete")
        {

            //string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });

            //string Standard = commandArgs[0];
            //string Subject = commandArgs[1];
            //string Chapter_No = commandArgs[2];
            //string Chapter_Name = commandArgs[3];
            //string Question_Name = commandArgs[4];
            //string Question_No = commandArgs[5];
            //string Option_A = commandArgs[6].ToString();
            //string Option_B = commandArgs[7].ToString();
            //string Option_C = commandArgs[8].ToString();
            //string Option_D = commandArgs[9].ToString();
            //string Correct_Ans = commandArgs[10];
            //string Explanation = commandArgs[11];
            string Q_ID = e.CommandArgument.ToString();

            string Option_A = "";
            string Option_B = "";
            string Option_C = "";
            string Option_D = "";

            System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings["ConString"].ConnectionString);
            con.Open();
            ++i;

            // string strQuery = "insert into CET_Chapter1(Standard,Subject,Chapter_ID,ChapterName) values (@Standard,@Subject,@ChapterNo,@ChapterNo)";

            string strQuery = "insert into CET_Select_Exam_Question1(Branch,Year,Semester,Subject,Chapter_No,Chapter_Name,Question_No,Question_Name,Correct_Ans,Explanation,Q_ID,ImgName,ContentType,Data,ImgNameA,ContentTypeA,DataA,ImgNameB,ContentTypeB,DataB,ImgNameC,ContentTypeC,DataC,ImgNameD,ContentTypeD,DataD,ImgNameE,ContentTypeE,DataE) (select Branch,Year,Semester,Subject,Chapter_No,Chapter_Name,Question_No,Question_Name,Correct_Ans,Explanation,Q_ID,ImgName,ContentType,Data,ImgNameA,ContentTypeA,DataA,ImgNameB,ContentTypeB,DataB,ImgNameC,ContentTypeC,DataC,ImgNameD,ContentTypeD,DataD,ImgNameE,ContentTypeE,DataE from CET_tbl_Question1 where Q_ID = '" + Q_ID + "')";
            SqlCommand cmd = new SqlCommand(strQuery);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            strQuery = "select Option_A,Option_B,Option_C,Option_D from CET_tbl_Question1 where Q_ID = '" + Q_ID + "'";
            cmd = new SqlCommand(strQuery);
            cmd.Connection = con;
            var obj = cmd.ExecuteReader();
            while (obj.Read())
            {
                Option_A = obj[0].ToString();
                Option_B = obj[1].ToString();
                Option_C = obj[2].ToString();
                Option_D = obj[3].ToString();
            }
            con.Close();
            con.Open();
            strQuery = "update CET_Select_Exam_Question1 set Option_A = '" + Option_A + "',Option_B = '" + Option_B + "',Option_C = '" + Option_C + "',Option_D = '" + Option_D + "' where id = (select max(id) from CET_Select_Exam_Question1)";
            cmd = new SqlCommand(strQuery);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            strQuery = "update CET_Select_Exam_Question1 set Que_Paper_id = '" + Que_Paper_Id + "' where id = (select max(id) from CET_Select_Exam_Question1)";
            cmd = new SqlCommand(strQuery);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            strQuery = "update CET_Select_Exam_Question1 set Question_No = '" + i + "' where id = (select max(id) from CET_Select_Exam_Question1)";
            cmd = new SqlCommand(strQuery);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            Response.Write("<script LANGUAGE='JavaSCript' > alert('Record Added Successfully')</script>");

            }
        }

    protected void btn_View_Click(object sender, EventArgs e)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        con.Open();

        var name = this.Request.Form["cat"];
        string branch = Session["branch"].ToString();
        string year = Session["year"].ToString();
        string sem = Session["sem"].ToString();
        string sub = Session["subject"].ToString();
        int TotalMarks = Convert.ToInt32(Session["marks"]);

        string strQuery = "insert into CET_QuestionPaperInfo1(Exam_ID,Branch,Year,Semester,Time,Total_Marks,Exam_Name,Subject) values (" + Que_Paper_Id + ",'" + branch + "','" + year + "','" + sem + "'," + Time + "," + TotalMarks + ", '" + name + "','" + sub + "')";
        SqlCommand cmd = new SqlCommand(strQuery,con);

        cmd.ExecuteNonQuery();

        Response.Write("<script LANGUAGE='JavaSCript' > alert('Exam Created Successfully For Exam ID " + Que_Paper_Id + " And Exam Name = " + name + "); window.location='Dashboard.aspx';</script>");
        Response.Redirect("Dashboard.aspx");
    }

    protected void abc_SelectedIndexChanged(object sender, EventArgs e)
    {
        /*string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);

        foreach (GridViewRow gvrow in abc.Rows)
        {
            CheckBox chk = (CheckBox)gvrow.FindControl("chkSelect");
            if (chk != null & chk.Checked)
            {
                con.Open();
                string strQuery = "insert into NMCE_Attendance(id,Name,Year,Branch,Date,Subject,TeacherID) values (@id,@Name,@Year,@Branch,@Date,@Subject,@TeacherID)";
                SqlCommand cmd = new SqlCommand(strQuery);
                cmd.Parameters.Add("@id", SqlDbType.VarChar).Value = gvrow.Cells[1].Text;
                cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = gvrow.Cells[2].Text;
                cmd.Parameters.Add("@Year", SqlDbType.VarChar).Value = gvrow.Cells[3].Text;
                cmd.Parameters.Add("@Branch", SqlDbType.VarChar).Value = gvrow.Cells[4].Text;
                cmd.Parameters.Add("@Date", SqlDbType.VarChar).Value = mon1;
                cmd.Parameters.Add("@Subject", SqlDbType.VarChar).Value = DropDownList1.Text;
                cmd.Parameters.Add("@TeacherID", SqlDbType.VarChar).Value = Session["id"].ToString();


                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                con.Close();

            }
        }
        Response.Write("<script LANGUAGE='JavaSCript' > alert('Questions Added Successfully')</script>");*/
    }
}