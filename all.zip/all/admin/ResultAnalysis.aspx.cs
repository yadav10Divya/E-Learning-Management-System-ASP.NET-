﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class StudentResultAnalysis : System.Web.UI.Page
{
    public int RollNo { get; set; }
    public string branch { get; set; }
    public int ExamNo { get; set; }
    public string Name { get; set; }

    public string PRN = null;

    public int Other = 0;


    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Session.Abandon();
            Response.Redirect("../Default.aspx");
        }
        if (!IsPostBack)
        {
             branch = Session["Branch"].ToString();
             RollNo = Convert.ToInt32(Session["PRN"]);
             ExamNo = Convert.ToInt32(Session["ExamID"]);
             PRN = Session["PRN"].ToString();
             Name = Session["Name"].ToString();


            string connectionString = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            DataTable dt1 = new DataTable();
            string Query1 = "Select SE.Question_No,SE.Question_Name As Question,SE.Option_A,SE.Option_B,SE.Option_C,SE.Option_D,SE.Correct_Ans,EA.SelectedOption,SE.Explanation,AnswerStatus from CET_Select_Exam_Question1 As SE left outer join CET_Exam_AnswerSheet1 As EA on(SE.Que_Paper_id = EA.PaperID and SE.Question_No = EA.Question) where SE.Que_Paper_id = " + ExamNo + " and EA.Branch = '" + branch + "' And EA.RollNo = " + Convert.ToInt32(Session["RollNo"]) + " and EA.PaperID = " + ExamNo + " and EA.PRN = '" + PRN + "'";
            SqlDataAdapter sda1 = new SqlDataAdapter(Query1, con);
            sda1.Fill(dt1);
            abc.DataSource = dt1;
            abc.DataBind();
        }
    }

    protected void abc_PreRender(object sender, EventArgs e)
    {
        abc.HeaderRow.TableSection = TableRowSection.TableHeader;
    }

    protected void Button2_Click(object sender, EventArgs e)
    {

    }
}