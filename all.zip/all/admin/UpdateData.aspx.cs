﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;

public partial class back_end_UpdateData : System.Web.UI.Page
{
    int id;
    public string ServerValue = String.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Session.Abandon();
            Response.Redirect("../Default.aspx");
        }

        if (!IsPostBack)
        {


            if (Request.QueryString["Subject_ID"] != null)
            {

                DropDownList1.Items.Clear();
                DropDownList2.Items.Clear();
                DropDownList3.Items.Clear();
                string sem = "";
                string branch = "";
                string year = "";

                id = int.Parse(Request.QueryString["Subject_ID"].ToString());

                string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
                SqlConnection con = new SqlConnection(connectionString);

                con.Open();
                SqlDataAdapter da = new SqlDataAdapter("Select * from CET_tblSubject1 where Subject_ID='" + id + "'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    ServerValue = dt.Rows[0][1].ToString();
                    sem = dt.Rows[0][2].ToString();
                    branch = dt.Rows[0][3].ToString();
                    year = dt.Rows[0][4].ToString();
                }
                con.Close();

                DropDownList2.Items.Clear();
                DropDownList2.Items.Add(branch);
                con.Open();
                SqlCommand cmd = new SqlCommand("Select Distinct(Name) from CET_branch1", con);
                cmd.Connection = con;
                var obj = cmd.ExecuteReader();
                while (obj.Read())
                {
                    DropDownList2.Items.Add(obj.GetString(obj.GetOrdinal("Name")));
                }
                obj.Dispose();
                con.Close();

                DropDownList3.Items.Insert(0, new ListItem(year, "NA")); //updated code
                DropDownList3.Items.Add("First Year");
                DropDownList3.Items.Add("Second Year");
                DropDownList3.Items.Add("Third Year");


                DropDownList1.Items.Insert(0, new ListItem(sem, "NA"));
                DropDownList1.Items.Add("Sem 1");
                DropDownList1.Items.Add("Sem 2");
                DropDownList1.Items.Add("Sem 3");
                DropDownList1.Items.Add("Sem 4");
                DropDownList1.Items.Add("Sem 5");
                DropDownList1.Items.Add("Sem 6");
            }
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        var name = this.Request.Form["cat"];
        string connectionString = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;

        SqlConnection con = new SqlConnection(connectionString);
        con.Open();

        id = int.Parse(Request.QueryString["Subject_ID"].ToString());

        string Query = "Update CET_tblSubject1 set Subject_Name = @Subject_Name, Semester = @sem,Branch = @branch,Year = @year where Subject_ID = @Subject_ID";
        SqlCommand cmd = new SqlCommand(Query, con);
   
        cmd.Parameters.Add(new SqlParameter("@Subject_ID",id ));
        cmd.Parameters.Add(new SqlParameter("@Subject_Name", name));
        cmd.Parameters.Add(new SqlParameter("@sem", DropDownList1.Text));
        cmd.Parameters.Add(new SqlParameter("@year", DropDownList3.Text));
        cmd.Parameters.Add(new SqlParameter("@branch", DropDownList2.Text));

        cmd.ExecuteNonQuery();
        Response.Write("<script LANGUAGE='JavaScript' >alert('Update Successfully')</script>");
        Response.Redirect("category.aspx");
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("category.aspx");
    }
}