﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Net;
using System.Net.Mail;

public partial class admin_StudRegister : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Session.Abandon();
            Response.Redirect("../Default.aspx");
        }
        GetData();


        //DropDownList1.Items.Clear();
        if(!IsPostBack)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);

            con.Open();
            SqlCommand cmd = new SqlCommand("Select Distinct(Name) from CET_branch1", con);
            cmd.Connection = con;
            var obj = cmd.ExecuteReader();
            while (obj.Read())
            {
                DropDownList1.Items.Add(obj.GetString(obj.GetOrdinal("Name")));
            }
            obj.Dispose();
            con.Close();

        }


    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    private void GetData()
    {
        string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ToString();
        SqlConnection con = new SqlConnection(connectionString);
        con.Open();
        SqlDataAdapter sda = new SqlDataAdapter("Select * from CET_tbl_Student_Register1", con);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        grdView.DataSource = dt;
        grdView.DataBind();

        count.Text = dt.Rows.Count.ToString();
    }
    protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdView.PageIndex = e.NewPageIndex;
        this.GetData();
    }
    protected void grdView_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "lnkbtnEdit")
        {
            string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
            string TeacherID = commandArgs[0];
            string TFName = commandArgs[1];
            string TMName = commandArgs[2];
            string TLName = commandArgs[3];
            string Subject = commandArgs[4];
            string MNo = commandArgs[5];
            string Add = commandArgs[6];

            Response.Redirect("UpdateStudent.aspx?Student_ID=" + TeacherID + "&SFName=" + TFName + "&SMName=" + TMName + "&SLName=" + TLName + "&STD=" + Subject + "&MNo=" + MNo + "&Address=" + Add + "&prn=" + commandArgs[7] + "&year=" + commandArgs[8] + "&sem=" + commandArgs[9] + "&seat=" + commandArgs[10] );
            GetData();
        }
        if (e.CommandName == "lnkbtnDelete")
        {
            string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
            string TeacherID = commandArgs[0];
            try
            {
                string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("Delete CET_tbl_Student_Register1 where Student_ID= " + Convert.ToInt32(TeacherID) + "");
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                Response.Write("<script LANGUAGE= 'JavaScript' >alert ('Record Delete Successfully')</Script>");
                GetData();
                con.Close();

            }
            catch (Exception ex)
            {

            }

        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();

        if (DropDownList1.Text == "All")
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ToString();
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select * from CET_tbl_Student_Register1", con);
            
            sda.Fill(dt);
            grdView.DataSource = dt;
            grdView.DataBind();
        }
        else if(DropDownList2.Text == "All")
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ToString();
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select * from CET_tbl_Student_Register1 where Branch = '" + DropDownList1.Text + "'", con);
            
            sda.Fill(dt);
            grdView.DataSource = dt;
            grdView.DataBind();
        }
        else if (DropDownList3.Text == "All")
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ToString();
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select * from CET_tbl_Student_Register1 where Branch = '" + DropDownList1.Text + "' and Year = '" + DropDownList2.Text + "'", con);
            
            sda.Fill(dt);
            grdView.DataSource = dt;
            grdView.DataBind();
        }
        else
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConString"].ToString();
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select * from CET_tbl_Student_Register1 where Branch = '" + DropDownList1.Text + "' and Year = '" + DropDownList2.Text + "' and Semester = '" + DropDownList3.Text + "'", con);
            
            sda.Fill(dt);
            grdView.DataSource = dt;
            grdView.DataBind();
        }

        count.Text = dt.Rows.Count.ToString();

    }
}

