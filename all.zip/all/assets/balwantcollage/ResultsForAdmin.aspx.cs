﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_ResultsForAdmin : System.Web.UI.Page
{
    public static string ExamID;
    public static int id;
    public string ExamBranch;
    public string year;
    public string sem;
    public string subject;
    public string marks;
    public string examtime;
    public string Time;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Session.Abandon();
            Response.Redirect("../Default.aspx");
        }
        if (Session["branch"] != null)
        {
            ExamBranch = Session["branch"].ToString();
        }
        if (Session["year"] != null)
        {
            year = Session["year"].ToString();
        }
        if (Session["sem"] != null)
        {
            year = Session["sem"].ToString();
        }
        if (Session["sem"] != null)
        {
            year = Session["subject"].ToString();
        }
        if (Session["marks"] != null)
        {
            year = Session["marks"].ToString();
        }
        if (Session["examtime"] != null)
        {
            year = Session["examtime"].ToString();
        }
        if (Session["Time"] != null)
        {
            year = Session["Time"].ToString();
        }
        if (!IsPostBack)
        {
            id = int.Parse(Request.QueryString["id"]);
           
            string connectionString = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            DataTable dt1 = new DataTable();
            string Query1 = "select ExamID,RollNo,Name,TotalQuestions,SolvedQuestions,TotalMarks,ObtainedMarks from CET_StudentResult1 where ExamID = " + id + " order by RollNo";
            SqlDataAdapter sda1 = new SqlDataAdapter(Query1, con);
            sda1.Fill(dt1);
            ExamID = id.ToString();
            abc.DataSource = dt1;
            abc.DataBind();
            SqlCommand cmd = new SqlCommand("select Exam_Name from CET_QuestionPaperInfo1 where Exam_ID = '" + ExamID + "'", con);
            ExamID = cmd.ExecuteScalar().ToString();

            int count = abc.Rows.Count;
            SqlCommand cmd1 = new SqlCommand("SELECT COUNT (ExamID) FROM  CET_StudentResult1 WHERE ExamID = " + id + "", con);
            attendcounter.Text = cmd1.ExecuteScalar().ToString();

            //absent

            SqlCommand cmd5 = new SqlCommand("select Branch from CET_StudentResult1 where ExamID = '" + id + "'", con);
            var obj = cmd5.ExecuteReader();

            if(obj.Read())
            {
                ExamBranch = (obj["Branch"].ToString());
            }
            cmd5.Dispose();
            obj.Dispose();

            DataTable dt2 = new DataTable();
            string Query2 = "SELECT * FROM CET_tbl_Student_Register1 WHERE Branch = '" + ExamBranch + "' AND PRN NOT IN (select PRN from CET_StudentResult1 WHERE ExamID = '" + id + "')";
            SqlDataAdapter sda2 = new SqlDataAdapter(Query2, con);
            sda2.Fill(dt2);
            ExamID = id.ToString();
            GridView1.DataSource = dt2;
            GridView1.DataBind();
            SqlCommand cmd2= new SqlCommand("select Exam_Name from CET_QuestionPaperInfo1 where Exam_ID = '" + ExamID + "'", con);
            ExamID = cmd2.ExecuteScalar().ToString();

            int count2 = GridView1.Rows.Count;
            SqlCommand cmd3 = new SqlCommand("SELECT COUNT (PRN) FROM CET_tbl_Student_Register1 WHERE Branch = '" + ExamBranch + "' AND PRN NOT IN (select PRN from CET_StudentResult1 WHERE ExamID = '" + id + "')",con);
            absentcounter.Text = cmd3.ExecuteScalar().ToString();
        }
    }
    //        SqlDataAdapter sda = new SqlDataAdapter("select a.Student_ID, a.Stud_First_Name, a.Stud_Middle_Name, a.Stud_Last_Name, a.Branch ,b.RollNo ,b.ExamID from CET_StudentResult1 a INNER JOIN CET_tbl_Student_Register1 b on a.PRN = b.PRN  where   f on b.id = f.Book_ID", con);
    protected void abc_SelectedIndexChanged(object sender, EventArgs e)
    {
        //int index = abc.SelectedRow.RowIndex;
        // int ID = Convert.ToInt32(abc.SelectedRow.Cells[0].Text);
        // string message = "Row Index: " + index + "\\ContactID: ";
        //  Response.Write("<script language='javascript'>window.alert('Record Updated Successfully ');</script>");
        foreach (GridViewRow row in abc.Rows)
        {
            if (row.RowIndex == abc.SelectedIndex)
            {
                row.BackColor = ColorTranslator.FromHtml("#A1DCF2");
                row.ToolTip = string.Empty;
            }
            else
            {
                row.BackColor = ColorTranslator.FromHtml("#FFFFFF");
                row.ToolTip = "Click to select this row.";
            }
        }
    }
    protected void abc_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(abc, "Select$" + e.Row.RowIndex);
            e.Row.ToolTip = "Click to select this row.";
        }
    }
    protected void Excel_Click(object sender, EventArgs e)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        con.Open();
        SqlCommand cmd6 = new SqlCommand("select Branch,Year,Semester,Subject,Total_Marks,Exam_Date,Time from CET_QuestionPaperInfo1 where Exam_ID = '" + id + "'", con);
        var obj = cmd6.ExecuteReader();
        if (obj.Read())
        {
            ExamBranch = (obj["branch"].ToString());
            year = (obj["year"].ToString());
            sem = (obj["Semester"].ToString());
            subject = (obj["subject"].ToString());
            marks = (obj["Total_Marks"].ToString());
            examtime = (obj["Exam_Date"].ToString());
            Time = (obj["Time"].ToString());
        }
        // Clear all content output from the buffer stream
        Response.ClearContent();

        // Specify the default file name using "content-disposition" RESPONSE header
        Response.AppendHeader("content-disposition", "attachment; filename=Student Attend Exam.xls");

        // Set excel as the HTTP MIME type
        Response.ContentType = "application/excel";

        // Create an instance of stringWriter for writing information to a string
        System.IO.StringWriter stringWriter = new System.IO.StringWriter();

        // Create an instance of HtmlTextWriter class for writing markup 
        // characters and text to an ASP.NET server control output stream
        HtmlTextWriter htw = new HtmlTextWriter(stringWriter);


        // Set white color as the background color for gridview header row
        abc.HeaderRow.Style.Add("background-color", "#FFFFFF");

        // Set background color of each cell of GridView1 header row
        foreach (TableCell tableCell in abc.HeaderRow.Cells)
        {
            tableCell.Style["background-color"] = "#A55129";
        }

        // Set background color of each cell of each data row of GridView1
        foreach (GridViewRow gridViewRow in abc.Rows)
        {
            gridViewRow.BackColor = System.Drawing.Color.White;
            foreach (TableCell gridViewRowTableCell in gridViewRow.Cells)
            {
                gridViewRowTableCell.Style["background-color"] = "#FFF7E7";
            }
        }
  
        abc.RenderControl(htw);

        string headerTable = @"<Table><tr><td><img ""http://localhost:49996/assets/balwantcollage/logo3.png""></td></tr></Table>";
        Response.Write(headerTable);
        string headerTable1 = @"<Table><tr>ExamName =" + ExamID + "</tr></Table>";
        Response.Write(headerTable1);
        string headerTable2 = @"<Table><tr>Branch =" + ExamBranch + "</tr></Table>";
        Response.Write(headerTable2);
        string headerTable3 = @"<Table><tr> Year =" + year + "</tr></Table>";
        Response.Write(headerTable3);
        string headerTable4 = @"<Table><tr><td> sem =" + sem + "</td></tr></Table>";
        Response.Write(headerTable4);
        string headerTable5 = @"<Table><td> subject =" + subject + "</td></Table>";
        Response.Write(headerTable5);
        string headerTable6 = @"<Table><tr><td> marks =" + marks + "</td></tr></Table>";
        Response.Write(headerTable6);
        string headerTable7 = @"<Table><tr><td> examtime =" + examtime + "</td></tr></Table>";
        Response.Write(headerTable7);
        string headerTable8 = @"<Table><tr><td> Time =" + Time + "</td></tr></Table>";
        Response.Write(headerTable8);
        Response.Write(stringWriter.ToString());
        Response.End();
    }
    protected void Excel2_Click(object sender, EventArgs e)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        con.Open();
        SqlCommand cmd6 = new SqlCommand("select Branch,Year,Semester,Subject,Total_Marks,Exam_Date,Time from CET_QuestionPaperInfo1 where Exam_ID = '" + id + "'", con);
        var obj = cmd6.ExecuteReader();
        if (obj.Read())
        {
            ExamBranch = (obj["branch"].ToString());
            year = (obj["year"].ToString());
            sem = (obj["Semester"].ToString());
            subject = (obj["subject"].ToString());
            marks = (obj["Total_Marks"].ToString());
            examtime = (obj["Exam_Date"].ToString());
            Time = (obj["Time"].ToString());
        }
        // Clear all content output from the buffer stream
        Response.ClearContent();

        // Specify the default file name using "content-disposition" RESPONSE header
        Response.AppendHeader("content-disposition", "attachment; filename=Student Not Attend Exam.xls");

        // Set excel as the HTTP MIME type
        Response.ContentType = "application/excel";

        // Create an instance of stringWriter for writing information to a string
        System.IO.StringWriter stringWriter = new System.IO.StringWriter();

        // Create an instance of HtmlTextWriter class for writing markup 
        // characters and text to an ASP.NET server control output stream
        HtmlTextWriter htw = new HtmlTextWriter(stringWriter);

        // Set white color as the background color for gridview header row
        GridView1.HeaderRow.Style.Add("background-color", "#FFFFFF");

        // Set background color of each cell of GridView1 header row
        foreach (TableCell tableCell in GridView1.HeaderRow.Cells)
        {
            tableCell.Style["background-color"] = "#A55129";
        }

        // Set background color of each cell of each data row of GridView1
        foreach (GridViewRow gridViewRow in GridView1.Rows)
        {
            gridViewRow.BackColor = System.Drawing.Color.White;
            foreach (TableCell gridViewRowTableCell in gridViewRow.Cells)
            {
                gridViewRowTableCell.Style["background-color"] = "#FFF7E7";
            }
        }

        GridView1.RenderControl(htw);
        string headerTable = @"<Table><tr><td><img ""http://localhost:49996/assets/balwantcollage/logo3.png""\></td></tr></Table>";
        Response.Write(headerTable);
        string headerTable1 = @"<Table><tr>ExamName =" + ExamID + "</tr></Table>";
        Response.Write(headerTable1);
        string headerTable2 = @"<Table><tr>Branch =" + ExamBranch + "</tr></Table>";
        Response.Write(headerTable2);
        string headerTable3 = @"<Table><tr> Year =" + year + "</tr></Table>";
        Response.Write(headerTable3);
        string headerTable4 = @"<Table><tr><td> sem =" + sem + "</td></tr></Table>";
        Response.Write(headerTable4);
        string headerTable5 = @"<Table><td> subject =" + subject + "</td></Table>";
        Response.Write(headerTable5);
        string headerTable6 = @"<Table><tr><td> marks =" + marks + "</td></tr></Table>";
        Response.Write(headerTable6);
        string headerTable7 = @"<Table><tr><td> examtime =" + examtime + "</td></tr></Table>";
        Response.Write(headerTable7);
        string headerTable8 = @"<Table><tr><td> Time =" + Time + "</td></tr></Table>";
        Response.Write(headerTable8);
        Response.Write(stringWriter.ToString());
        Response.End();

    }
    public override void VerifyRenderingInServerForm(Control control)
    {

    }

    protected void abc_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if(e.CommandName == "viewassesment")
        {
            string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });

            string RollNo = commandArgs[0];
            string Name = commandArgs[1];
            string ExamID = commandArgs[2];
            // string CName = commandArgs[3];
            //string QNo = commandArgs[4];
            //string QName = commandArgs[5];
            //string OptionA = commandArgs[6];
            //string OptionB = commandArgs[7];
            //string OptionC = commandArgs[8];
            //string OptionD = commandArgs[9];
            //string C_Ans = commandArgs[10];
            //string Explanation = commandArgs[11];

            Response.Redirect("StudentAssesmentView.aspx?RollNo=" + RollNo + " &Name=" + Name + " &ExamID=" + ExamID);

            //Session["RollNo"] = e.CommandArgument.ToString();
            //Session["Name"] = e.CommandArgument.ToString();
            Response.Redirect("StudentAssesmentView.aspx");
        }
    }
}