/*!
 * Bootstrap v3.3.6 (http://getbootstrap.com)
 * Copyright 2011-2015 Twitter, Inc.
 * Licensed under the MIT license
 */

/*
 * jQuery FlexSlider v2.6.3
 * Copyright 2012 WooThemes
 * Contributing Author: Tyler Smith
 */
!function($){var e=!0;$.flexslider=function(t,a){var n=$(t);n.vars=$.extend({},$.flexslider.defaults,a);var i=n.vars.namespace,s=window.navigator&&window.navigator.msPointerEnabled&&window.MSGesture,r=("ontouchstart"in window||s||window.DocumentTouch&&document instanceof DocumentTouch)&&n.vars.touch,o="click touchend MSPointerUp keyup",l="",c,d="vertical"===n.vars.direction,u=n.vars.reverse,v=n.vars.itemWidth>0,p="fade"===n.vars.animation,m=""!==n.vars.asNavFor,f={};$.data(t,"flexslider",n),f={init:function(){n.animating=!1,n.currentSlide=parseInt(n.vars.startAt?n.vars.startAt:0,10),isNaN(n.currentSlide)&&(n.currentSlide=0),n.animatingTo=n.currentSlide,n.atEnd=0===n.currentSlide||n.currentSlide===n.last,n.containerSelector=n.vars.selector.substr(0,n.vars.selector.search(" ")),n.slides=$(n.vars.selector,n),n.container=$(n.containerSelector,n),n.count=n.slides.length,n.syncExists=$(n.vars.sync).length>0,"slide"===n.vars.animation&&(n.vars.animation="swing"),n.prop=d?"top":"marginLeft",n.args={},n.manualPause=!1,n.stopped=!1,n.started=!1,n.startTimeout=null,n.transitions=!n.vars.video&&!p&&n.vars.useCSS&&function(){var e=document.createElement("div"),t=["perspectiveProperty","WebkitPerspective","MozPerspective","OPerspective","msPerspective"];for(var a in t)if(void 0!==e.style[t[a]])return n.pfx=t[a].replace("Perspective","").toLowerCase(),n.prop="-"+n.pfx+"-transform",!0;return!1}(),n.ensureAnimationEnd="",""!==n.vars.controlsContainer&&(n.controlsContainer=$(n.vars.controlsContainer).length>0&&$(n.vars.controlsContainer)),""!==n.vars.manualControls&&(n.manualControls=$(n.vars.manualControls).length>0&&$(n.vars.manualControls)),""!==n.vars.customDirectionNav&&(n.customDirectionNav=2===$(n.vars.customDirectionNav).length&&$(n.vars.customDirectionNav)),n.vars.randomize&&(n.slides.sort(function(){return Math.round(Math.random())-.5}),n.container.empty().append(n.slides)),n.doMath(),n.setup("init"),n.vars.controlNav&&f.controlNav.setup(),n.vars.directionNav&&f.directionNav.setup(),n.vars.keyboard&&(1===$(n.containerSelector).length||n.vars.multipleKeyboard)&&$(document).bind("keyup",function(e){var t=e.keyCode;if(!n.animating&&(39===t||37===t)){var a=39===t?n.getTarget("next"):37===t?n.getTarget("prev"):!1;n.flexAnimate(a,n.vars.pauseOnAction)}}),n.vars.mousewheel&&n.bind("mousewheel",function(e,t,a,i){e.preventDefault();var s=0>t?n.getTarget("next"):n.getTarget("prev");n.flexAnimate(s,n.vars.pauseOnAction)}),n.vars.pausePlay&&f.pausePlay.setup(),n.vars.slideshow&&n.vars.pauseInvisible&&f.pauseInvisible.init(),n.vars.slideshow&&(n.vars.pauseOnHover&&n.hover(function(){n.manualPlay||n.manualPause||n.pause()},function(){n.manualPause||n.manualPlay||n.stopped||n.play()}),n.vars.pauseInvisible&&f.pauseInvisible.isHidden()||(n.vars.initDelay>0?n.startTimeout=setTimeout(n.play,n.vars.initDelay):n.play())),m&&f.asNav.setup(),r&&n.vars.touch&&f.touch(),(!p||p&&n.vars.smoothHeight)&&$(window).bind("resize orientationchange focus",f.resize),n.find("img").attr("draggable","false"),setTimeout(function(){n.vars.start(n)},200)},asNav:{setup:function(){n.asNav=!0,n.animatingTo=Math.floor(n.currentSlide/n.move),n.currentItem=n.currentSlide,n.slides.removeClass(i+"active-slide").eq(n.currentItem).addClass(i+"active-slide"),s?(t._slider=n,n.slides.each(function(){var e=this;e._gesture=new MSGesture,e._gesture.target=e,e.addEventListener("MSPointerDown",function(e){e.preventDefault(),e.currentTarget._gesture&&e.currentTarget._gesture.addPointer(e.pointerId)},!1),e.addEventListener("MSGestureTap",function(e){e.preventDefault();var t=$(this),a=t.index();$(n.vars.asNavFor).data("flexslider").animating||t.hasClass("active")||(n.direction=n.currentItem<a?"next":"prev",n.flexAnimate(a,n.vars.pauseOnAction,!1,!0,!0))})})):n.slides.on(o,function(e){e.preventDefault();var t=$(this),a=t.index(),s=t.offset().left-$(n).scrollLeft();0>=s&&t.hasClass(i+"active-slide")?n.flexAnimate(n.getTarget("prev"),!0):$(n.vars.asNavFor).data("flexslider").animating||t.hasClass(i+"active-slide")||(n.direction=n.currentItem<a?"next":"prev",n.flexAnimate(a,n.vars.pauseOnAction,!1,!0,!0))})}},controlNav:{setup:function(){n.manualControls?f.controlNav.setupManual():f.controlNav.setupPaging()},setupPaging:function(){var e="thumbnails"===n.vars.controlNav?"control-thumbs":"control-paging",t=1,a,s;if(n.controlNavScaffold=$('<ol class="'+i+"control-nav "+i+e+'"></ol>'),n.pagingCount>1)for(var r=0;r<n.pagingCount;r++){s=n.slides.eq(r),void 0===s.attr("data-thumb-alt")&&s.attr("data-thumb-alt","");var c=""!==s.attr("data-thumb-alt")?c=' alt="'+s.attr("data-thumb-alt")+'"':"";if(a="thumbnails"===n.vars.controlNav?'<img src="'+s.attr("data-thumb")+'"'+c+"/>":'<a href="#">'+t+"</a>","thumbnails"===n.vars.controlNav&&!0===n.vars.thumbCaptions){var d=s.attr("data-thumbcaption");""!==d&&void 0!==d&&(a+='<span class="'+i+'caption">'+d+"</span>")}n.controlNavScaffold.append("<li>"+a+"</li>"),t++}n.controlsContainer?$(n.controlsContainer).append(n.controlNavScaffold):n.append(n.controlNavScaffold),f.controlNav.set(),f.controlNav.active(),n.controlNavScaffold.delegate("a, img",o,function(e){if(e.preventDefault(),""===l||l===e.type){var t=$(this),a=n.controlNav.index(t);t.hasClass(i+"active")||(n.direction=a>n.currentSlide?"next":"prev",n.flexAnimate(a,n.vars.pauseOnAction))}""===l&&(l=e.type),f.setToClearWatchedEvent()})},setupManual:function(){n.controlNav=n.manualControls,f.controlNav.active(),n.controlNav.bind(o,function(e){if(e.preventDefault(),""===l||l===e.type){var t=$(this),a=n.controlNav.index(t);t.hasClass(i+"active")||(a>n.currentSlide?n.direction="next":n.direction="prev",n.flexAnimate(a,n.vars.pauseOnAction))}""===l&&(l=e.type),f.setToClearWatchedEvent()})},set:function(){var e="thumbnails"===n.vars.controlNav?"img":"a";n.controlNav=$("."+i+"control-nav li "+e,n.controlsContainer?n.controlsContainer:n)},active:function(){n.controlNav.removeClass(i+"active").eq(n.animatingTo).addClass(i+"active")},update:function(e,t){n.pagingCount>1&&"add"===e?n.controlNavScaffold.append($('<li><a href="#">'+n.count+"</a></li>")):1===n.pagingCount?n.controlNavScaffold.find("li").remove():n.controlNav.eq(t).closest("li").remove(),f.controlNav.set(),n.pagingCount>1&&n.pagingCount!==n.controlNav.length?n.update(t,e):f.controlNav.active()}},directionNav:{setup:function(){var e=$('<ul class="'+i+'direction-nav"><li class="'+i+'nav-prev"><a class="'+i+'prev" href="#">'+n.vars.prevText+'</a></li><li class="'+i+'nav-next"><a class="'+i+'next" href="#">'+n.vars.nextText+"</a></li></ul>");n.customDirectionNav?n.directionNav=n.customDirectionNav:n.controlsContainer?($(n.controlsContainer).append(e),n.directionNav=$("."+i+"direction-nav li a",n.controlsContainer)):(n.append(e),n.directionNav=$("."+i+"direction-nav li a",n)),f.directionNav.update(),n.directionNav.bind(o,function(e){e.preventDefault();var t;""!==l&&l!==e.type||(t=$(this).hasClass(i+"next")?n.getTarget("next"):n.getTarget("prev"),n.flexAnimate(t,n.vars.pauseOnAction)),""===l&&(l=e.type),f.setToClearWatchedEvent()})},update:function(){var e=i+"disabled";1===n.pagingCount?n.directionNav.addClass(e).attr("tabindex","-1"):n.vars.animationLoop?n.directionNav.removeClass(e).removeAttr("tabindex"):0===n.animatingTo?n.directionNav.removeClass(e).filter("."+i+"prev").addClass(e).attr("tabindex","-1"):n.animatingTo===n.last?n.directionNav.removeClass(e).filter("."+i+"next").addClass(e).attr("tabindex","-1"):n.directionNav.removeClass(e).removeAttr("tabindex")}},pausePlay:{setup:function(){var e=$('<div class="'+i+'pauseplay"><a href="#"></a></div>');n.controlsContainer?(n.controlsContainer.append(e),n.pausePlay=$("."+i+"pauseplay a",n.controlsContainer)):(n.append(e),n.pausePlay=$("."+i+"pauseplay a",n)),f.pausePlay.update(n.vars.slideshow?i+"pause":i+"play"),n.pausePlay.bind(o,function(e){e.preventDefault(),""!==l&&l!==e.type||($(this).hasClass(i+"pause")?(n.manualPause=!0,n.manualPlay=!1,n.pause()):(n.manualPause=!1,n.manualPlay=!0,n.play())),""===l&&(l=e.type),f.setToClearWatchedEvent()})},update:function(e){"play"===e?n.pausePlay.removeClass(i+"pause").addClass(i+"play").html(n.vars.playText):n.pausePlay.removeClass(i+"play").addClass(i+"pause").html(n.vars.pauseText)}},touch:function(){function e(e){e.stopPropagation(),n.animating?e.preventDefault():(n.pause(),t._gesture.addPointer(e.pointerId),T=0,c=d?n.h:n.w,f=Number(new Date),l=v&&u&&n.animatingTo===n.last?0:v&&u?n.limit-(n.itemW+n.vars.itemMargin)*n.move*n.animatingTo:v&&n.currentSlide===n.last?n.limit:v?(n.itemW+n.vars.itemMargin)*n.move*n.currentSlide:u?(n.last-n.currentSlide+n.cloneOffset)*c:(n.currentSlide+n.cloneOffset)*c)}function a(e){e.stopPropagation();var a=e.target._slider;if(a){var n=-e.translationX,i=-e.translationY;return T+=d?i:n,m=T,y=d?Math.abs(T)<Math.abs(-n):Math.abs(T)<Math.abs(-i),e.detail===e.MSGESTURE_FLAG_INERTIA?void setImmediate(function(){t._gesture.stop()}):void((!y||Number(new Date)-f>500)&&(e.preventDefault(),!p&&a.transitions&&(a.vars.animationLoop||(m=T/(0===a.currentSlide&&0>T||a.currentSlide===a.last&&T>0?Math.abs(T)/c+2:1)),a.setProps(l+m,"setTouch"))))}}function i(e){e.stopPropagation();var t=e.target._slider;if(t){if(t.animatingTo===t.currentSlide&&!y&&null!==m){var a=u?-m:m,n=a>0?t.getTarget("next"):t.getTarget("prev");t.canAdvance(n)&&(Number(new Date)-f<550&&Math.abs(a)>50||Math.abs(a)>c/2)?t.flexAnimate(n,t.vars.pauseOnAction):p||t.flexAnimate(t.currentSlide,t.vars.pauseOnAction,!0)}r=null,o=null,m=null,l=null,T=0}}var r,o,l,c,m,f,g,h,S,y=!1,x=0,b=0,T=0;s?(t.style.msTouchAction="none",t._gesture=new MSGesture,t._gesture.target=t,t.addEventListener("MSPointerDown",e,!1),t._slider=n,t.addEventListener("MSGestureChange",a,!1),t.addEventListener("MSGestureEnd",i,!1)):(g=function(e){n.animating?e.preventDefault():(window.navigator.msPointerEnabled||1===e.touches.length)&&(n.pause(),c=d?n.h:n.w,f=Number(new Date),x=e.touches[0].pageX,b=e.touches[0].pageY,l=v&&u&&n.animatingTo===n.last?0:v&&u?n.limit-(n.itemW+n.vars.itemMargin)*n.move*n.animatingTo:v&&n.currentSlide===n.last?n.limit:v?(n.itemW+n.vars.itemMargin)*n.move*n.currentSlide:u?(n.last-n.currentSlide+n.cloneOffset)*c:(n.currentSlide+n.cloneOffset)*c,r=d?b:x,o=d?x:b,t.addEventListener("touchmove",h,!1),t.addEventListener("touchend",S,!1))},h=function(e){x=e.touches[0].pageX,b=e.touches[0].pageY,m=d?r-b:r-x,y=d?Math.abs(m)<Math.abs(x-o):Math.abs(m)<Math.abs(b-o);var t=500;(!y||Number(new Date)-f>t)&&(e.preventDefault(),!p&&n.transitions&&(n.vars.animationLoop||(m/=0===n.currentSlide&&0>m||n.currentSlide===n.last&&m>0?Math.abs(m)/c+2:1),n.setProps(l+m,"setTouch")))},S=function(e){if(t.removeEventListener("touchmove",h,!1),n.animatingTo===n.currentSlide&&!y&&null!==m){var a=u?-m:m,i=a>0?n.getTarget("next"):n.getTarget("prev");n.canAdvance(i)&&(Number(new Date)-f<550&&Math.abs(a)>50||Math.abs(a)>c/2)?n.flexAnimate(i,n.vars.pauseOnAction):p||n.flexAnimate(n.currentSlide,n.vars.pauseOnAction,!0)}t.removeEventListener("touchend",S,!1),r=null,o=null,m=null,l=null},t.addEventListener("touchstart",g,!1))},resize:function(){!n.animating&&n.is(":visible")&&(v||n.doMath(),p?f.smoothHeight():v?(n.slides.width(n.computedW),n.update(n.pagingCount),n.setProps()):d?(n.viewport.height(n.h),n.setProps(n.h,"setTotal")):(n.vars.smoothHeight&&f.smoothHeight(),n.newSlides.width(n.computedW),n.setProps(n.computedW,"setTotal")))},smoothHeight:function(e){if(!d||p){var t=p?n:n.viewport;e?t.animate({height:n.slides.eq(n.animatingTo).innerHeight()},e):t.innerHeight(n.slides.eq(n.animatingTo).innerHeight())}},sync:function(e){var t=$(n.vars.sync).data("flexslider"),a=n.animatingTo;switch(e){case"animate":t.flexAnimate(a,n.vars.pauseOnAction,!1,!0);break;case"play":t.playing||t.asNav||t.play();break;case"pause":t.pause()}},uniqueID:function(e){return e.filter("[id]").add(e.find("[id]")).each(function(){var e=$(this);e.attr("id",e.attr("id")+"_clone")}),e},pauseInvisible:{visProp:null,init:function(){var e=f.pauseInvisible.getHiddenProp();if(e){var t=e.replace(/[H|h]idden/,"")+"visibilitychange";document.addEventListener(t,function(){f.pauseInvisible.isHidden()?n.startTimeout?clearTimeout(n.startTimeout):n.pause():n.started?n.play():n.vars.initDelay>0?setTimeout(n.play,n.vars.initDelay):n.play()})}},isHidden:function(){var e=f.pauseInvisible.getHiddenProp();return e?document[e]:!1},getHiddenProp:function(){var e=["webkit","moz","ms","o"];if("hidden"in document)return"hidden";for(var t=0;t<e.length;t++)if(e[t]+"Hidden"in document)return e[t]+"Hidden";return null}},setToClearWatchedEvent:function(){clearTimeout(c),c=setTimeout(function(){l=""},3e3)}},n.flexAnimate=function(e,t,a,s,o){if(n.vars.animationLoop||e===n.currentSlide||(n.direction=e>n.currentSlide?"next":"prev"),m&&1===n.pagingCount&&(n.direction=n.currentItem<e?"next":"prev"),!n.animating&&(n.canAdvance(e,o)||a)&&n.is(":visible")){if(m&&s){var l=$(n.vars.asNavFor).data("flexslider");if(n.atEnd=0===e||e===n.count-1,l.flexAnimate(e,!0,!1,!0,o),n.direction=n.currentItem<e?"next":"prev",l.direction=n.direction,Math.ceil((e+1)/n.visible)-1===n.currentSlide||0===e)return n.currentItem=e,n.slides.removeClass(i+"active-slide").eq(e).addClass(i+"active-slide"),!1;n.currentItem=e,n.slides.removeClass(i+"active-slide").eq(e).addClass(i+"active-slide"),e=Math.floor(e/n.visible)}if(n.animating=!0,n.animatingTo=e,t&&n.pause(),n.vars.before(n),n.syncExists&&!o&&f.sync("animate"),n.vars.controlNav&&f.controlNav.active(),v||n.slides.removeClass(i+"active-slide").eq(e).addClass(i+"active-slide"),n.atEnd=0===e||e===n.last,n.vars.directionNav&&f.directionNav.update(),e===n.last&&(n.vars.end(n),n.vars.animationLoop||n.pause()),p)r?(n.slides.eq(n.currentSlide).css({opacity:0,zIndex:1}),n.slides.eq(e).css({opacity:1,zIndex:2}),n.wrapup(c)):(n.slides.eq(n.currentSlide).css({zIndex:1}).animate({opacity:0},n.vars.animationSpeed,n.vars.easing),n.slides.eq(e).css({zIndex:2}).animate({opacity:1},n.vars.animationSpeed,n.vars.easing,n.wrapup));else{var c=d?n.slides.filter(":first").height():n.computedW,g,h,S;v?(g=n.vars.itemMargin,S=(n.itemW+g)*n.move*n.animatingTo,h=S>n.limit&&1!==n.visible?n.limit:S):h=0===n.currentSlide&&e===n.count-1&&n.vars.animationLoop&&"next"!==n.direction?u?(n.count+n.cloneOffset)*c:0:n.currentSlide===n.last&&0===e&&n.vars.animationLoop&&"prev"!==n.direction?u?0:(n.count+1)*c:u?(n.count-1-e+n.cloneOffset)*c:(e+n.cloneOffset)*c,n.setProps(h,"",n.vars.animationSpeed),n.transitions?(n.vars.animationLoop&&n.atEnd||(n.animating=!1,n.currentSlide=n.animatingTo),n.container.unbind("webkitTransitionEnd transitionend"),n.container.bind("webkitTransitionEnd transitionend",function(){clearTimeout(n.ensureAnimationEnd),n.wrapup(c)}),clearTimeout(n.ensureAnimationEnd),n.ensureAnimationEnd=setTimeout(function(){n.wrapup(c)},n.vars.animationSpeed+100)):n.container.animate(n.args,n.vars.animationSpeed,n.vars.easing,function(){n.wrapup(c)})}n.vars.smoothHeight&&f.smoothHeight(n.vars.animationSpeed)}},n.wrapup=function(e){p||v||(0===n.currentSlide&&n.animatingTo===n.last&&n.vars.animationLoop?n.setProps(e,"jumpEnd"):n.currentSlide===n.last&&0===n.animatingTo&&n.vars.animationLoop&&n.setProps(e,"jumpStart")),n.animating=!1,n.currentSlide=n.animatingTo,n.vars.after(n)},n.animateSlides=function(){!n.animating&&e&&n.flexAnimate(n.getTarget("next"))},n.pause=function(){clearInterval(n.animatedSlides),n.animatedSlides=null,n.playing=!1,n.vars.pausePlay&&f.pausePlay.update("play"),n.syncExists&&f.sync("pause")},n.play=function(){n.playing&&clearInterval(n.animatedSlides),n.animatedSlides=n.animatedSlides||setInterval(n.animateSlides,n.vars.slideshowSpeed),n.started=n.playing=!0,n.vars.pausePlay&&f.pausePlay.update("pause"),n.syncExists&&f.sync("play")},n.stop=function(){n.pause(),n.stopped=!0},n.canAdvance=function(e,t){var a=m?n.pagingCount-1:n.last;return t?!0:m&&n.currentItem===n.count-1&&0===e&&"prev"===n.direction?!0:m&&0===n.currentItem&&e===n.pagingCount-1&&"next"!==n.direction?!1:e!==n.currentSlide||m?n.vars.animationLoop?!0:n.atEnd&&0===n.currentSlide&&e===a&&"next"!==n.direction?!1:!n.atEnd||n.currentSlide!==a||0!==e||"next"!==n.direction:!1},n.getTarget=function(e){return n.direction=e,"next"===e?n.currentSlide===n.last?0:n.currentSlide+1:0===n.currentSlide?n.last:n.currentSlide-1},n.setProps=function(e,t,a){var i=function(){var a=e?e:(n.itemW+n.vars.itemMargin)*n.move*n.animatingTo,i=function(){if(v)return"setTouch"===t?e:u&&n.animatingTo===n.last?0:u?n.limit-(n.itemW+n.vars.itemMargin)*n.move*n.animatingTo:n.animatingTo===n.last?n.limit:a;switch(t){case"setTotal":return u?(n.count-1-n.currentSlide+n.cloneOffset)*e:(n.currentSlide+n.cloneOffset)*e;case"setTouch":return u?e:e;case"jumpEnd":return u?e:n.count*e;case"jumpStart":return u?n.count*e:e;default:return e}}();return-1*i+"px"}();n.transitions&&(i=d?"translate3d(0,"+i+",0)":"translate3d("+i+",0,0)",a=void 0!==a?a/1e3+"s":"0s",n.container.css("-"+n.pfx+"-transition-duration",a),n.container.css("transition-duration",a)),n.args[n.prop]=i,(n.transitions||void 0===a)&&n.container.css(n.args),n.container.css("transform",i)},n.setup=function(e){if(p)n.slides.css({width:"100%","float":"left",marginRight:"-100%",position:"relative"}),"init"===e&&(r?n.slides.css({opacity:0,display:"block",webkitTransition:"opacity "+n.vars.animationSpeed/1e3+"s ease",zIndex:1}).eq(n.currentSlide).css({opacity:1,zIndex:2}):0==n.vars.fadeFirstSlide?n.slides.css({opacity:0,display:"block",zIndex:1}).eq(n.currentSlide).css({zIndex:2}).css({opacity:1}):n.slides.css({opacity:0,display:"block",zIndex:1}).eq(n.currentSlide).css({zIndex:2}).animate({opacity:1},n.vars.animationSpeed,n.vars.easing)),n.vars.smoothHeight&&f.smoothHeight();else{var t,a;"init"===e&&(n.viewport=$('<div class="'+i+'viewport"></div>').css({overflow:"hidden",position:"relative"}).appendTo(n).append(n.container),n.cloneCount=0,n.cloneOffset=0,u&&(a=$.makeArray(n.slides).reverse(),n.slides=$(a),n.container.empty().append(n.slides))),n.vars.animationLoop&&!v&&(n.cloneCount=2,n.cloneOffset=1,"init"!==e&&n.container.find(".clone").remove(),n.container.append(f.uniqueID(n.slides.first().clone().addClass("clone")).attr("aria-hidden","true")).prepend(f.uniqueID(n.slides.last().clone().addClass("clone")).attr("aria-hidden","true"))),n.newSlides=$(n.vars.selector,n),t=u?n.count-1-n.currentSlide+n.cloneOffset:n.currentSlide+n.cloneOffset,d&&!v?(n.container.height(200*(n.count+n.cloneCount)+"%").css("position","absolute").width("100%"),setTimeout(function(){n.newSlides.css({display:"block"}),n.doMath(),n.viewport.height(n.h),n.setProps(t*n.h,"init")},"init"===e?100:0)):(n.container.width(200*(n.count+n.cloneCount)+"%"),n.setProps(t*n.computedW,"init"),setTimeout(function(){n.doMath(),n.newSlides.css({width:n.computedW,marginRight:n.computedM,"float":"left",display:"block"}),n.vars.smoothHeight&&f.smoothHeight()},"init"===e?100:0))}v||n.slides.removeClass(i+"active-slide").eq(n.currentSlide).addClass(i+"active-slide"),n.vars.init(n)},n.doMath=function(){var e=n.slides.first(),t=n.vars.itemMargin,a=n.vars.minItems,i=n.vars.maxItems;n.w=void 0===n.viewport?n.width():n.viewport.width(),n.h=e.height(),n.boxPadding=e.outerWidth()-e.width(),v?(n.itemT=n.vars.itemWidth+t,n.itemM=t,n.minW=a?a*n.itemT:n.w,n.maxW=i?i*n.itemT-t:n.w,n.itemW=n.minW>n.w?(n.w-t*(a-1))/a:n.maxW<n.w?(n.w-t*(i-1))/i:n.vars.itemWidth>n.w?n.w:n.vars.itemWidth,n.visible=Math.floor(n.w/n.itemW),n.move=n.vars.move>0&&n.vars.move<n.visible?n.vars.move:n.visible,n.pagingCount=Math.ceil((n.count-n.visible)/n.move+1),n.last=n.pagingCount-1,n.limit=1===n.pagingCount?0:n.vars.itemWidth>n.w?n.itemW*(n.count-1)+t*(n.count-1):(n.itemW+t)*n.count-n.w-t):(n.itemW=n.w,n.itemM=t,n.pagingCount=n.count,n.last=n.count-1),n.computedW=n.itemW-n.boxPadding,n.computedM=n.itemM},n.update=function(e,t){n.doMath(),v||(e<n.currentSlide?n.currentSlide+=1:e<=n.currentSlide&&0!==e&&(n.currentSlide-=1),n.animatingTo=n.currentSlide),n.vars.controlNav&&!n.manualControls&&("add"===t&&!v||n.pagingCount>n.controlNav.length?f.controlNav.update("add"):("remove"===t&&!v||n.pagingCount<n.controlNav.length)&&(v&&n.currentSlide>n.last&&(n.currentSlide-=1,n.animatingTo-=1),f.controlNav.update("remove",n.last))),n.vars.directionNav&&f.directionNav.update()},n.addSlide=function(e,t){var a=$(e);n.count+=1,n.last=n.count-1,d&&u?void 0!==t?n.slides.eq(n.count-t).after(a):n.container.prepend(a):void 0!==t?n.slides.eq(t).before(a):n.container.append(a),n.update(t,"add"),n.slides=$(n.vars.selector+":not(.clone)",n),n.setup(),n.vars.added(n)},n.removeSlide=function(e){var t=isNaN(e)?n.slides.index($(e)):e;n.count-=1,n.last=n.count-1,isNaN(e)?$(e,n.slides).remove():d&&u?n.slides.eq(n.last).remove():n.slides.eq(e).remove(),n.doMath(),n.update(t,"remove"),n.slides=$(n.vars.selector+":not(.clone)",n),n.setup(),n.vars.removed(n)},f.init()},$(window).blur(function(t){e=!1}).focus(function(t){e=!0}),$.flexslider.defaults={namespace:"flex-",selector:".slides > li",animation:"fade",easing:"swing",direction:"horizontal",reverse:!1,animationLoop:!0,smoothHeight:!1,startAt:0,slideshow:!0,slideshowSpeed:7e3,animationSpeed:600,initDelay:0,randomize:!1,fadeFirstSlide:!0,thumbCaptions:!1,pauseOnAction:!0,pauseOnHover:!1,pauseInvisible:!0,useCSS:!0,touch:!0,video:!1,controlNav:!0,directionNav:!0,prevText:"Previous",nextText:"Next",keyboard:!0,multipleKeyboard:!1,mousewheel:!1,pausePlay:!1,pauseText:"Pause",playText:"Play",controlsContainer:"",manualControls:"",customDirectionNav:"",sync:"",asNavFor:"",itemWidth:0,itemMargin:0,minItems:1,maxItems:0,move:0,allowOneSlide:!0,start:function(){},before:function(){},after:function(){},end:function(){},added:function(){},removed:function(){},init:function(){}},$.fn.flexslider=function(e){if(void 0===e&&(e={}),"object"==typeof e)return this.each(function(){var t=$(this),a=e.selector?e.selector:".slides > li",n=t.find(a);1===n.length&&e.allowOneSlide===!1||0===n.length?(n.fadeIn(400),e.start&&e.start(t)):void 0===t.data("flexslider")&&new $.flexslider(this,e)});var t=$(this).data("flexslider");switch(e){case"play":t.play();break;case"pause":t.pause();break;case"stop":t.stop();break;case"next":t.flexAnimate(t.getTarget("next"),!0);break;case"prev":case"previous":t.flexAnimate(t.getTarget("prev"),!0);break;default:"number"==typeof e&&t.flexAnimate(e,!0)}}}(jQuery);

/* Accessible Mega Menu JS */
!function(e,t,s){"use strict";function a(t,s){this.element=t,this.settings=e.extend({},o,s),this._defaults=o,this._name=l,this.mouseTimeoutID=null,this.focusTimeoutID=null,this.mouseFocused=!1,this.justFocused=!1,this.init()}function n(t){return e.expr.filters.visible(t)&&!e(t).parents().addBack().filter(function(){return"hidden"===e.css(this,"visibility")}).length}function i(t,s){var a,i,l,o=t.nodeName.toLowerCase();return"area"===o?(a=t.parentNode,i=a.name,t.href&&i&&"map"===a.nodeName.toLowerCase()?(l=e("img[usemap=#"+i+"]")[0],!!l&&n(l)):!1):(/input|select|textarea|button|object/.test(o)?!t.disabled:"a"===o?t.href||s:s)&&n(t)}var l="accessibleMegaMenu",o={uuidPrefix:"menu",menuClass:"menu",topNavItemClass:"menu-top-nav-item",panelClass:"menu-panel",panelGroupClass:"menu-panel-group",hoverClass:"hover",focusClass:"focus",openClass:"open"},r={BACKSPACE:8,COMMA:188,DELETE:46,DOWN:40,END:35,ENTER:13,ESCAPE:27,HOME:36,LEFT:37,PAGE_DOWN:34,PAGE_UP:33,PERIOD:190,RIGHT:39,SPACE:32,TAB:9,UP:38,keyMap:{48:"0",49:"1",50:"2",51:"3",52:"4",53:"5",54:"6",55:"7",56:"8",57:"9",59:";",65:"a",66:"b",67:"c",68:"d",69:"e",70:"f",71:"g",72:"h",73:"i",74:"j",75:"k",76:"l",77:"m",78:"n",79:"o",80:"p",81:"q",82:"r",83:"s",84:"t",85:"u",86:"v",87:"w",88:"x",89:"y",90:"z",96:"0",97:"1",98:"2",99:"3",100:"4",101:"5",102:"6",103:"7",104:"8",105:"9",190:"."}};a.prototype=function(){var n,i,o,u,f,c,d,h,p,b,m,g,C,x=0,v=1e3,y="",T="function"==typeof t.hasOwnProperty&&!!t.hasOwnProperty("ontouchstart");return n=function(t){return e(t).closest(":data(plugin_"+l+")").data("plugin_"+l)},i=function(t){t=e(t);var s=this.settings;t.attr("id")||t.attr("id",s.uuidPrefix+"-"+(new Date).getTime()+"-"+ ++x)},o=function(t,a){var n,i=e(t.target),l=this,o=this.settings,u=this.menu,f=i.closest("."+o.topNavItemClass),c=i.hasClass(o.panelClass)?i:i.closest("."+o.panelClass);if(C.call(this,!0),a)if(f=u.find("."+o.topNavItemClass+" ."+o.openClass+":first").closest("."+o.topNavItemClass),f.is(t.relatedTarget)||f.has(t.relatedTarget).length>0)0===f.length&&u.find("[aria-expanded=true]").attr("aria-expanded","false").removeClass(o.openClass).filter("."+o.panelClass).attr("aria-hidden","true");else{if(("mouseout"===t.type||"focusout"===t.type)&&f.has(s.activeElement).length>0)return;f.find("[aria-expanded]").attr("aria-expanded","false").removeClass(o.openClass).filter("."+o.panelClass).attr("aria-hidden","true"),("keydown"===t.type&&t.keyCode===r.ESCAPE||"DOMAttrModified"===t.type)&&(n=f.find(":tabbable:first"),setTimeout(function(){u.find("[aria-expanded]."+l.settings.panelClass).off("DOMAttrModified.menu"),n.focus(),l.justFocused=!1},99))}else clearTimeout(l.focusTimeoutID),f.siblings().find("[aria-expanded]").attr("aria-expanded","false").removeClass(o.openClass).filter("."+o.panelClass).attr("aria-hidden","true"),f.find("[aria-expanded]").attr("aria-expanded","true").addClass(o.openClass).filter("."+o.panelClass).attr("aria-hidden","false"),"mouseover"===t.type&&i.is(":tabbable")&&1===f.length&&0===c.length&&u.has(s.activeElement).length>0&&(i.focus(),l.justFocused=!1),C.call(l)},u=function(t){var s=e(t.currentTarget),a=s.closest("."+this.settings.topNavItemClass),n=s.closest("."+this.settings.panelClass);1===a.length&&0===n.length&&1===a.find("."+this.settings.panelClass).length&&s.hasClass(this.settings.openClass)&&this.justFocused},f=function(t){0===e(t.target).closest(this.menu).length&&(t.preventDefault(),t.stopPropagation(),o.call(this,t,!0))},c=function(t){"aria-expanded"===t.originalEvent.attrName&&"false"===t.originalEvent.newValue&&e(t.target).hasClass(this.settings.openClass)&&(t.preventDefault(),t.stopPropagation(),o.call(this,t,!0))},d=function(t){clearTimeout(this.focusTimeoutID);var s=e(t.target),a=s.closest("."+this.settings.panelClass);s.addClass(this.settings.focusClass).on("click.menu",e.proxy(u,this)),this.justFocused=!this.mouseFocused,this.mouseFocused=!1,this.panels.not(a).filter("."+this.settings.openClass).length&&o.call(this,t)},h=function(s){this.justFocused=!1;var a=this,n=e(s.target),i=n.closest("."+this.settings.topNavItemClass);n.removeClass(this.settings.focusClass).off("click.menu"),t.cvox?a.focusTimeoutID=setTimeout(function(){t.cvox.Api.getCurrentNode(function(e){i.has(e).length?clearTimeout(a.focusTimeoutID):a.focusTimeoutID=setTimeout(function(e,t,s){o.call(e,t,s)},275,a,s,!0)})},25):a.focusTimeoutID=setTimeout(function(){o.call(a,s,!0)},300)},p=function(s){var i,l,f,c,d,h,p=this.constructor===a?this:n(this),b=p.settings,m=e(e(this).is("."+b.hoverClass+":tabbable")?this:s.target),g=p.menu,C=p.topnavitems,x=m.closest("."+b.topNavItemClass),T=g.find(":tabbable"),D=m.hasClass(b.panelClass)?m:m.closest("."+b.panelClass),E=D.find("."+b.panelGroupClass),k=m.closest("."+b.panelGroupClass),I=s.keyCode||s.which,N=!1,w=r.keyMap[s.keyCode]||"",A=1===x.length&&0===D.length;if(!m.is("input:focus, select:focus, textarea:focus, button:focus")){switch(m.is("."+b.hoverClass+":tabbable")&&e("html").off("keydown.menu"),I){case r.ESCAPE:o.call(p,s,!0);break;case r.DOWN:s.preventDefault(),A?(o.call(p,s),N=1===x.find("."+b.panelClass+" :tabbable:first").focus().length):N=1===T.filter(":gt("+T.index(m)+"):first").focus().length,!N&&t.opera&&"[object Opera]"===opera.toString()&&(s.ctrlKey||s.metaKey)&&(T=e(":tabbable"),f=T.index(m),N=1===e(":tabbable:gt("+e(":tabbable").index(m)+"):first").focus().length);break;case r.UP:s.preventDefault(),A&&m.hasClass(b.openClass)?(o.call(p,s,!0),i=C.filter(":lt("+C.index(x)+"):last"),i.children("."+b.panelClass).length&&(N=1===i.children().attr("aria-expanded","true").addClass(b.openClass).filter("."+b.panelClass).attr("aria-hidden","false").find(":tabbable:last").focus())):A||(N=1===T.filter(":lt("+T.index(m)+"):last").focus().length),!N&&t.opera&&"[object Opera]"===opera.toString()&&(s.ctrlKey||s.metaKey)&&(T=e(":tabbable"),f=T.index(m),N=1===e(":tabbable:lt("+e(":tabbable").index(m)+"):first").focus().length);break;case r.RIGHT:s.preventDefault(),A?N=1===C.filter(":gt("+C.index(x)+"):first").find(":tabbable:first").focus().length:(E.length&&k.length&&(N=1===E.filter(":gt("+E.index(k)+"):first").find(":tabbable:first").focus().length),N||(N=1===x.find(":tabbable:first").focus().length));break;case r.LEFT:s.preventDefault(),A?N=1===C.filter(":lt("+C.index(x)+"):last").find(":tabbable:first").focus().length:(E.length&&k.length&&(N=1===E.filter(":lt("+E.index(k)+"):last").find(":tabbable:first").focus().length),N||(N=1===x.find(":tabbable:first").focus().length));break;case r.TAB:f=T.index(m),s.shiftKey&&A&&m.hasClass(b.openClass)?(o.call(p,s,!0),i=C.filter(":lt("+C.index(x)+"):last"),i.children("."+b.panelClass).length&&(N=i.children().attr("aria-expanded","true").addClass(b.openClass).filter("."+b.panelClass).attr("aria-hidden","false").find(":tabbable:last").focus())):s.shiftKey&&f>0?N=1===T.filter(":lt("+f+"):last").focus().length:!s.shiftKey&&f<T.length-1?N=1===T.filter(":gt("+f+"):first").focus().length:t.opera&&"[object Opera]"===opera.toString()&&(T=e(":tabbable"),f=T.index(m),N=s.shiftKey?1===e(":tabbable:lt("+e(":tabbable").index(m)+"):last").focus().length:1===e(":tabbable:gt("+e(":tabbable").index(m)+"):first").focus().length),N&&s.preventDefault();break;case r.SPACE:if(!A)return!0;s.preventDefault(),u.call(p,s);break;case r.ENTER:return!0;default:if(clearTimeout(this.keydownTimeoutID),y+=w!==y?w:"",0===y.length)return;for(this.keydownTimeoutID=setTimeout(function(){y=""},v),T=A&&!m.hasClass(b.openClass)?T.filter(":not(."+b.panelClass+" :tabbable)"):x.find(":tabbable"),s.shiftKey&&(T=e(T.get().reverse())),f=0;f<T.length;f++)if(c=T.eq(f),c.is(m)){l=1===y.length?f+1:f;break}for(h=new RegExp("^"+y.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g,"\\$&"),"i"),f=l;f<T.length;f++)if(c=T.eq(f),d=e.trim(c.text()),h.test(d)){N=!0,c.focus();break}if(!N)for(f=0;l>f;f++)if(c=T.eq(f),d=e.trim(c.text()),h.test(d)){c.focus();break}}p.justFocused=!1}},b=function(t){(e(t.target).is(this.settings.panelClass)||e(t.target).closest(":focusable").length)&&(this.mouseFocused=!0),this.mouseTimeoutID=setTimeout(function(){clearTimeout(this.focusTimeoutID)},1)},m=function(t){clearTimeout(this.mouseTimeoutID),e(t.target).addClass(this.settings.hoverClass),o.call(this,t),e(t.target).is(":tabbable")&&e("html").on("keydown.menu",e.proxy(p,t.target))},g=function(t){var s=this;e(t.target).removeClass(s.settings.hoverClass),s.mouseTimeoutID=setTimeout(function(){o.call(s,t,!0)},250),e(t.target).is(":tabbable")&&e("html").off("keydown.menu")},C=function(t){var s=this.menu;t?(e("html").off("mouseup.outside-menu, touchend.outside-menu, mspointerup.outside-menu,  pointerup.outside-menu"),s.find("[aria-expanded]."+this.settings.panelClass).off("DOMAttrModified.menu")):(e("html").on("mouseup.outside-menu, touchend.outside-menu, mspointerup.outside-menu,  pointerup.outside-menu",e.proxy(f,this)),s.find("[aria-expanded=true]."+this.settings.panelClass).on("DOMAttrModified.menu",e.proxy(c,this)))},{constructor:a,init:function(){var t=this.settings,s=e(this.element),a=s.children().first(),n=a.children();this.start(t,s,a,n)},start:function(t,a,n,l){var o=this;this.settings=t,this.menu=n,this.topnavitems=l,a.attr("role","navigation"),n.addClass(t.menuClass),l.each(function(s,a){var n,l;a=e(a),a.addClass(t.topNavItemClass),n=a.find(":tabbable:first"),l=a.children(":not(:tabbable):last"),i.call(o,n),l.length&&(i.call(o,l),n.attr({"aria-haspopup":!0,"aria-controls":l.attr("id"),"aria-expanded":!1}),l.attr({role:"group","aria-expanded":!1,"aria-hidden":!0}).addClass(t.panelClass).not("[aria-labelledby]").attr("aria-labelledby",n.attr("id")))}),this.panels=n.find("."+t.panelClass),n.on("focusin.menu",":focusable, ."+t.panelClass,e.proxy(d,this)).on("focusout.menu",":focusable, ."+t.panelClass,e.proxy(h,this)).on("keydown.menu",e.proxy(p,this)).on("mouseover.menu",e.proxy(m,this)).on("mouseout.menu",e.proxy(g,this)).on("mousedown.menu",e.proxy(b,this)),T&&n.on("touchstart.menu",e.proxy(u,this)),n.find("hr").attr("role","separator"),e(s.activeElement).closest(n).length&&e(s.activeElement).trigger("focusin.menu")},getDefaults:function(){return this._defaults},getOption:function(e){return this.settings[e]},getAllOptions:function(){return this.settings},setOption:function(e,t,s){this.settings[e]=t,s&&this.init()}}}(),e.fn[l]=function(t){return this.each(function(){e.data(this,"plugin_"+l)||e.data(this,"plugin_"+l,new e.fn[l].AccessibleMegaMenu(this,t))})},e.fn[l].AccessibleMegaMenu=a,e.extend(e.expr[":"],{data:e.expr.createPseudo?e.expr.createPseudo(function(t){return function(s){return!!e.data(s,t)}}):function(t,s,a){return!!e.data(t,a[3])},focusable:function(t){return i(t,!isNaN(e.attr(t,"tabindex")))},tabbable:function(t){var s=e.attr(t,"tabindex"),a=isNaN(s);return(a||s>=0)&&i(t,!a)}})}(jQuery,window,document);

/* Custom Nav Functions */

/*================================================================================
  = MOBILE NAV            
  ================================================================================*/

        $(function() {
            // run test on initial page load
            checkSize();

            // run test on resize of the window
            $(window).resize(checkSize);
        });

        //Add toggle menu arrows
        // Add a <span> to every .nav-item that has a <ul> inside
        // Parent link arrow
        $('.vcuhp-nav-item').has('.parent-link').prepend('<span class="nav-click"><i class="fa fa-angle-down nav-arrow"></i></span>');
        // Secondary link arrow
        $('li.nav-submenu-item').has('ul').prepend('<span class="nav-click-2"><i class="fa fa-angle-down nav-arrow"></i></span>');
    

        // Conditions for toggle mobile nav function
        function toggleNav() {
            if ($('body').hasClass('show-mobile-nav')) {
                // Do things on Nav Close
                $('body').removeClass('show-mobile-nav');
            } else {
                // Do things on Nav Open
                $('body').addClass('show-mobile-nav');
            }
        }

        // 1. Let's display the mobile nav!
        // Function to toggle visibility of mobile nav
        $('.toggle-nav-btn').click(function() {
            toggleNav();
        });

        // 2. Let's display the mobile nav submenu!
        $('.nav-main').on('click', '.nav-click', function() {

            // Toggle the nested nav
            $(this).siblings('.nav-submenu').toggle();

            // Toggle the submenu arrow using CSS3 transforms
            $(this).children('.nav-arrow').toggleClass('nav-rotate');

            // Toggle the submenu arrow using CSS3 transforms
            $(this).siblings('.parent-link').toggleClass('show-subnav');

        });

        // 2. Let's display the third-level mobile nav submenu!
        $('.nav-main').on('click', '.nav-click-2', function() {

            // Toggle the nested nav
            $(this).siblings('.nav-submenu-2').toggle();

            // Toggle the submenu arrow using CSS3 transforms
            $(this).children('.nav-arrow').toggleClass('nav-rotate');

            // Toggle the submenu arrow using CSS3 transforms
            $(this).siblings('.parent-link').toggleClass('show-subnav');

        });

        ///////////////////////////////////////////

        // 1. Let's hendle the searchbox!
        // Function to toggle visibility of search
        $('.searchbox-open-btn').click(function(e) {
            if ($('body').hasClass('show-searchbox')) {
                // Do things on Nav Close
                e.preventDefault();
                $('body').removeClass('show-searchbox');
            } else {
                // Do things on Nav Open
                e.preventDefault(e);
                $('body').addClass('show-searchbox');
            }
        });

        // Function to toggle visibility of search
        $('.searchbox-close-btn').click(function(e) {
            if ($('body').hasClass('show-searchbox')) {
                // Do things on Nav Close
                e.preventDefault();
                $('body').removeClass('show-searchbox');
            } else {
                // Do nothing!
            }
        });

        // Function to toggle visibility of search
        $('.main-search-overlay').click(function(e) {
            if ($('body').hasClass('show-searchbox')) {
                // Do things on Nav Close
                e.preventDefault();
                $('body').removeClass('show-searchbox');
            } else {
                // Do nothing!
            }
        });

        /////////////////////////////////////////

        // Conditions for toggle quicklinks nav
        function toggleQuicklinks() {
          //if ($(".mobile-overlay").css("z-index") != "0") {

            if ($('.mobile').hasClass('show-quicklinks')) {
                // Do things on Nav Close
                $('.mobile').removeClass('show-quicklinks');
            } else {
                // Do things on Nav Open
                $('.mobile').addClass('show-quicklinks');
            }
          //}
        }
        $('.nav-quicklinks').click(function() {
            toggleQuicklinks();
        });

        /////////////////////////////////////////

        //Function to the css rule
        // On load and resize check for match with css rule
        function checkSize() {
           if ($(".mobile-overlay").css("z-index") == "0") {
            
            // If .mobile-overlay class < 767px breakpoint
            // We are using z-index rule as the hook
                
               // Remove class and attr
               $('body').addClass('desktop');
               $('body').removeClass('mobile');
               $('body').removeClass('show-mobile-nav');
               $('.nav-arrow').removeClass('nav-rotate'); // reset arrow
               $('.parent-link').removeClass('show-subnav'); // reset arrow
               $('.nav-submenu').removeAttr('style'); // remove inline
               
               // Show audience nav in header
               $('.nav-audience-list').prependTo('.vcuhp-audience-nav');
               $('.nav-audience-list a').removeClass('btn');
               $('.nav-audience-list a').removeClass('btn-pill');
               
            } else {

               $('body').removeClass('desktop');
               $('body').addClass('mobile');
              // Show audience nav in mobile menu
               $('.nav-audience-list').insertAfter('.nav-main');
               $('.nav-audience-list a').addClass('btn');
               $('.nav-audience-list a').addClass('btn-pill');

            }
        }

/*================================================================================
  = Quicklinks Menu - Toggle class for hidden/visible
  ================================================================================*/

        $('.nav-quicklinks .nav-submenu-dropdown').bind('blur', function () {
            $(this).addClass('.quicklinks-hidden');
        }).bind('focus', function () {
            $(this).addClass('.quicklinks-visible');
        });

/*================================================================================
  = Searchbox form - Placeholder text
  ================================================================================*/

        $(document).on('focus' , 'input.sb' , function () {

            $(this).removeAttr('placeholder');

        });

        $(document).on('focusout' , 'input.sb' , function () {

            if($(this).val() == ''){
                $(this).attr('placeholder' , 'Search VCU people and web');
            }

        });

/*================================================================================
  = Active Nav - Add active class to main menu for current section
  ================================================================================*/

        (function( $ ) {
            $.fn.activeNavigation = function(selector) {
                var pathname = window.location.pathname
                var extension_position;
                var href;
                var hrefs = []
                $(selector).find("a.parent-link").each(function(){
                    // Remove href file extension
                    extension_position = $(this).attr("href").lastIndexOf('.');
                    href = (extension_position >= 0) ? $(this).attr("href").substr(0, extension_position) : $(this).attr("href");

                    if (pathname.indexOf(href) > -1) {
                        hrefs.push($(this));
                    }
                })
                if (hrefs.length) {
                    hrefs.sort(function(a,b){
                        return b.attr("href").length - a.attr("href").length
                    })
                    hrefs[0].addClass("vcuhp-active")
                }
            };
        })(jQuery);

        $(document).activeNavigation(".vcuhp-header-nav");
       
/*================================================================================
  = Init accessible-mega-menu.js - Make main menu keyboard accessible
  ================================================================================*/    
     
        $('nav.vcuhp-header-nav').accessibleMegaMenu({
          // prefix for generated unique id attributes, which are required
          // to indicate aria-owns, aria-controls and aria-labelledby
          uuidPrefix: 'vcuhp-header-nav',

          // CSS class used to define the megamenu styling
          menuClass: 'nav-main',

          // CSS class for a top-level navigation item in the megamenu
          topNavItemClass: 'nav-item',

          // CSS class for a megamenu panel
          panelClass: 'nav-submenu',

          // CSS class for a group of items within a megamenu panel
          panelGroupClass: 'vcuhp-submenu-list',

          // CSS class for the hover state
          hoverClass: 'hover',

          // CSS class for the focus state
          focusClass: 'focus',

          // CSS class for the open state
          openClass: 'open'
        });

/*================================================================================
  = Init accessible-mega-menu.js - Make quicklinks menu keyboard accessible
  ================================================================================*/    
     
        $('div.icon-nav-parent').accessibleMegaMenu({
          // prefix for generated unique id attributes, which are required
          // to indicate aria-owns, aria-controls and aria-labelledby
          uuidPrefix: 'icon-nav-parent',

          // CSS class used to define the megamenu styling
          menuClass: 'nav-icon-list',

          // CSS class for a top-level navigation item in the megamenu
          topNavItemClass: 'nav-item',

          // CSS class for a megamenu panel
          panelClass: 'nav-submenu-dropdown',

          // CSS class for a group of items within a megamenu panel
          panelGroupClass: 'nav-quicklinks-group',

          // CSS class for the hover state
          hoverClass: 'hover',

          // CSS class for the focus state
          focusClass: 'focus',

          // CSS class for the open state
          openClass: 'open'
        });

// END base js

/*================================================================================
  = Hide sidebar parent link if no subnav menu is found
  ================================================================================*/

      if($('.triple-subnav-gutter ul').length === 0){
           $('.triple-subnav-gutter').addClass("no-subnav");
      }

/*================================================================================
  = Accordion with toggle icon
  ================================================================================*/

        function toggleIcon(e) {
              $(e.target)
                  .prev('.panel-heading')
                  .find(".more-less")
                  .toggleClass('fa-plus fa-minus');
          }
          $('.panel-group').on('hidden.bs.collapse', toggleIcon);
          $('.panel-group').on('shown.bs.collapse', toggleIcon);
        
/*================================================================================
  = Open Tab from a Link (ie, Admissions Checklist link)
  ================================================================================*/
        
        $(function(){
          var hash = window.location.hash;
          hash && $('ul.nav a[href="' + hash + '"]').tab('show');

          $('.nav-tabs a').click(function (e) {
            $(this).tab('show');
            var scrollmem = $('body').scrollTop() || $('html').scrollTop();
            window.location.hash = this.hash;
            $('html,body').scrollTop(scrollmem);
          });
        });

/*================================================================================
  = Open Modal Slideshow (ie, RVA Image Grid on Admissions index)
  ================================================================================*/

        $(document).ready(function(){

            loadGallery(true, 'a.image-grid-thumbnail');

            //This function disables buttons when needed
            function disableButtons(counter_max, counter_current){
                $('#show-previous-image, #show-next-image').show();
                if(counter_max == counter_current){
                    $('#show-next-image').hide();
                } else if (counter_current == 1){
                    $('#show-previous-image').hide();
                }
            }

            /**
             *
             * @param setIDs        Sets IDs when DOM is loaded. If using a PHP counter, set to false.
             * @param setClickAttr  Sets the attribute for the click handler.
             */

            function loadGallery(setIDs, setClickAttr){
                var current_image,
                    selector,
                    counter = 0;

                $('#show-next-image, #show-previous-image').click(function(){
                    if($(this).attr('id') == 'show-previous-image'){
                        current_image--;
                    } else {
                        current_image++;
                    }

                    selector = $('[data-image-id="' + current_image + '"]');
                    updateGallery(selector);
                });

                function updateGallery(selector) {
                    var $sel = selector;
                    current_image = $sel.data('image-id');
                    $('#image-gallery-caption').text($sel.data('caption'));
                    $('#image-gallery-title').text($sel.data('title'));
                    $('#image-gallery-image').attr('src', $sel.data('image'));
                    disableButtons(counter, $sel.data('image-id'));
                }

                if(setIDs == true){
                    $('[data-image-id]').each(function(){
                        counter++;
                        $(this).attr('data-image-id',counter);
                    });
                }
                $(setClickAttr).on('click',function(){
                    updateGallery($(this));
                });
            }
        });

/*================================================================================
  = Hero Slideshow > flexslider > w/ fallback for css object-fit support (IE)
  ================================================================================*/
        
        $(window).load(function() {
          
          // Load flexslider
          $('.hero-slideshow .flexslider').flexslider({
            touch: true,
            slideshow: false,
            controlNav: true,
            slideshowSpeed: 7000,
            animationSpeed: 600,
            initDelay: 0,
            controlsContainer: $(".custom-controls-container"),
            customDirectionNav: $(".custom-navigation a")
          });

          // If css 'object-fit' not supported (IE)
          // Convert inline img into background-image
          // Can't use Modernizr, does not recognize 'objectfit'
          // This script works, but only applying bg image to first slide!
          // Need to debug! mh

          var csstest = jQuery( '.vcuhp-footer' )[0];
          var objectfit = getComputedStyle( csstest, ':before' ).content;
          if( objectfit == 'none' ) {
            console.log('Yes');
            $('.hero-slideshow .hero-img-container').each(function () {
              var $container = $(this),
                  imgUrl = $container.find('img').prop('src');
              if (imgUrl) {
                $container
                .css('backgroundImage', 'url(' + imgUrl + ')')
                .addClass('compat-object-fit');
              }

            });

          } else {
            console.log('No');
          }

        });

        // Prevent prev/next links from scrolling to id 
        $('.custom-navigation a').click(function(event) {
            event.preventDefault();
        });

/*================================================================================
  = Hero Slideshow > Toggle Caption (click caption icon to view)
  ================================================================================*/

        // Conditions for toggle caption
        function toggleCaption() {
            if ($('.hero-img-wrapper').hasClass('show-caption')) {
                // Do things on Caption Close
                $('.hero-img-wrapper').removeClass('show-caption');
            } else {
                // Do things on Caption Open
                $('.hero-img-wrapper').addClass('show-caption');
            }
        }

        // Let's display the captoin
        // Function to toggle visibility of mobile nav
        $('.hero-caption-icon').click(function() {
            toggleCaption();
        });

/*================================================================================
  = Flexslider > Click link to specific slide (ie, All about RVA slideshow
  ================================================================================*/

        $('.goto-slideshow-section').click(function(){
          event.preventDefault();
          var sectionid = $(this).attr('rel').valueOf(); // use rel attibute
          var sectionidNo = parseInt(sectionid); // get value of rel attribute
          var slider = $('.gallery-shortcode-flexslider').data('flexslider');
          var animationSpeed = slider.vars.animationSpeed;
          slider.vars.animationSpeed = 0; // remove animation
          slider.flexAnimate(sectionidNo); // slide to go to, onclick
          slider.vars.animationSpeed = animationSpeed;
        });

/*================================================================================
  = Sidebar Subnav > Add class if parent ul has a sub-level child ul
  ================================================================================*/

        // Add Class to LI with Child UL (Level 1)
        $('.section-subnav-list li ul').parent().addClass('hasChild');

/*================================================================================
  = YouTube Custom poster frame image - click event
  ================================================================================*/

        // poster frame click event
        $(document).on('click','.js-videoPoster',function(ev) {
          ev.preventDefault();
          var $poster = $(this);
          var $wrapper = $poster.closest('.js-videoWrapper');
          videoPlay($wrapper);
        });

        // play the targeted video (and hide the poster frame)
        function videoPlay($wrapper) {
          var $iframe = $wrapper.find('.js-videoIframe');
          var src = $iframe.data('src');
          // hide poster
          $wrapper.addClass('videoWrapperActive');
          // add iframe src in, starting the video
          $iframe.attr('src',src);
        }

        // stop the targeted/all videos (and re-instate the poster frames)
        function videoStop($wrapper) {
          // if we're stopping all videos on page
          if (!$wrapper) {
            var $wrapper = $('.js-videoWrapper');
            var $iframe = $('.js-videoIframe');
          // if we're stopping a particular video
          } else {
            var $iframe = $wrapper.find('.js-videoIframe');
          }
          // reveal poster
          $wrapper.removeClass('videoWrapperActive');
          // remove youtube link, stopping the video from playing in the background
          $iframe.attr('src','');
        }

/*================================================================================
  = Admissions/International Students - Add 'International' word before page title 
  ================================================================================*/

        $('#vcuhp-30685 .vcuhp-section-pagetitle').prepend('International ');
        $('#vcuhp-30686 .vcuhp-section-pagetitle').prepend('International ');

/*================================================================================
  = Responsive tables - Get header column text
  ================================================================================*/

        // For each table within the content area...
        $('.triple-main table').each(function(t){
          // Add a unique id if one doesn't exist.
          if (!this.id) {
            this.id = 'table_' + t;
          }
          // Prepare empty variables.
          var headertext = [],
              theads = document.querySelectorAll('#' + this.id + ' thead'),
              headers = document.querySelectorAll('#' + this.id + ' th'),
              tablerows = document.querySelectorAll('#' + this.id + ' th'),
              tablebody = document.querySelector('#' + this.id + ' tbody');
          // For tables with theads...
          for(var i = 0; i < theads.length; i++) {
            // If they have more than 2 columns...
            if (headers.length > 2) {
              // Add a responsive class.
              this.classList.add('responsive');
              // Get the content of the appropriate th.
              for(var i = 0; i < headers.length; i++) {
                var current = headers[i];
                headertext.push(current.textContent.replace(/\r?\n|\r/,''));
              }
              // Apply that as a data-th attribute on the corresponding cells.
              for (var i = 0, row; row = tablebody.rows[i]; i++) {
                for (var j = 0, col; col = row.cells[j]; j++) {
                  col.setAttribute('data-th', headertext[j]);
                }
              }
            }
          }
        });                                                

/*================================================================================
  = Add Scope Attribute to Table TH Tag (for columns accessibility)
  ================================================================================*/
                                                  
	$(function() {
        // Add scope=col to table th tag                                        
        $('.triple-main table th').attr('scope', 'col');                                          
    	console.log( 'dev:att scope attr' );                                        
	});